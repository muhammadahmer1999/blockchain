#ifndef MEMPOOL_H
#define MEMPOOL_H

#include "../src/transaction.h"
#include <vector>
#include <unordered_map>
#include <mutex>
#include <memory>
#include <functional>
#include <chrono>

/**
 * @class MemPool
 * @brief Memory pool for pending transactions
 * 
 * The MemPool stores pending transactions that have not yet been included in blocks.
 * It provides functionality for adding, removing, and retrieving transactions,
 * as well as prioritizing them based on fees and timestamps.
 */
class MemPool {
public:
    /**
     * Transaction status in mempool
     */
    enum class TxStatus {
        PENDING,    // Waiting to be mined
        PROCESSING, // Currently being processed
        INVALID,    // Found to be invalid
        CONFIRMED,  // Confirmed in a block
        EXPIRED     // Expired due to time in mempool
    };
    
    /**
     * Structure to hold transaction with metadata
     */
    struct TxEntry {
        Transaction transaction;
        TxStatus status;
        std::chrono::system_clock::time_point addedTime;
        double fee;
        size_t priority;        // Transaction priority (higher = more important)
        double feePerByte;      // Fee per byte ratio (for priority calculation)
        std::string sourceNode; // ID of node that originated the transaction
    };
    
    /**
     * Mempool configuration structure
     */
    struct MemPoolConfig {
        bool isMainnet;                // Whether running in mainnet mode
        size_t maxTransactions;        // Maximum number of transactions in pool
        size_t maxSizeBytes;           // Maximum size of mempool in bytes
        size_t minFeeRate;             // Minimum fee rate to accept transaction
        uint64_t maxTransactionAge;    // Maximum age in seconds before transaction expires
        bool prioritizeBySizeAndFee;   // Whether to prioritize by size and fee
        bool enableRBF;                // Enable Replace-By-Fee
        size_t cleanupIntervalSeconds; // How often to clean up expired transactions
    };
    
    /**
     * Default constructor - initialize with testnet defaults
     */
    MemPool();
    
    /**
     * Constructor with mainnet flag
     * 
     * @param isMainnet Whether to use mainnet settings
     */
    explicit MemPool(bool isMainnet);
    
    /**
     * Add a transaction to the mempool
     * @param transaction The transaction to add
     * @return True if successful, false if transaction already exists
     */
    bool addTransaction(const Transaction& transaction);
    
    /**
     * Remove a transaction from the mempool
     * @param txHash Hash of the transaction to remove
     * @return True if successful, false if transaction not found
     */
    bool removeTransaction(const std::string& txHash);
    
    /**
     * Get a transaction by hash
     * @param txHash Hash of the transaction to retrieve
     * @return Shared pointer to the transaction entry, or nullptr if not found
     */
    std::shared_ptr<TxEntry> getTransaction(const std::string& txHash) const;
    
    /**
     * Get all transactions with a specific status
     * @param status Status to filter by (default: PENDING)
     * @return Vector of transaction entries with the specified status
     */
    std::vector<TxEntry> getTransactionsByStatus(TxStatus status = TxStatus::PENDING) const;
    
    /**
     * Get all pending transactions (up to a limit)
     * @param limit Maximum number of transactions to return (0 for all)
     * @return Vector of pending transactions
     */
    std::vector<Transaction> getPendingTransactions(size_t limit = 0) const;
    
    /**
     * Update transaction status
     * @param txHash Hash of the transaction to update
     * @param status New status
     * @return True if successful, false if transaction not found
     */
    bool updateTransactionStatus(const std::string& txHash, TxStatus status);
    
    /**
     * Get the number of transactions with a specific status
     * @param status Status to count (default: all statuses)
     * @return Number of transactions
     */
    size_t getTransactionCount(TxStatus status = TxStatus::PENDING) const;
    
    /**
     * Clear all transactions from the mempool
     */
    void clear();
    
    /**
     * Remove all transactions older than a specific time
     * @param cutoffTime Time cutoff for transaction removal
     * @return Number of transactions removed
     */
    size_t pruneOldTransactions(const std::chrono::system_clock::time_point& cutoffTime);
    
    /**
     * Process pending transactions with a custom function
     * @param processor Function to process each transaction
     * @param limit Maximum number of transactions to process (0 for all)
     */
    void processTransactions(std::function<void(const Transaction&)> processor, size_t limit = 0);
    
private:
    /**
     * Map of transaction hash to transaction entry
     */
    std::unordered_map<std::string, std::shared_ptr<TxEntry>> m_transactions;
    
    /**
     * Mempool configuration
     */
    MemPoolConfig m_config;
    
    /**
     * Last cleanup timestamp
     */
    std::chrono::system_clock::time_point m_lastCleanupTime;
    
    /**
     * Current mempool size in bytes (approximate)
     */
    size_t m_currentSizeBytes;
    
    /**
     * Mutex for thread-safe access to transactions
     */
    mutable std::mutex m_mutex;
    
    /**
     * Generate transaction hash
     * @param transaction Transaction to hash
     * @return Hash string
     */
    std::string generateTxHash(const Transaction& transaction) const;
    
    /**
     * Calculate transaction size in bytes (approximate)
     * @param transaction Transaction to measure
     * @return Size in bytes
     */
    size_t calculateTxSize(const Transaction& transaction) const;
    
    /**
     * Calculate transaction priority based on fee and size
     * @param transaction Transaction to prioritize
     * @param fee Transaction fee
     * @return Priority value
     */
    size_t calculateTxPriority(const Transaction& transaction, double fee) const;
    
    /**
     * Cleanup expired transactions and enforce size limits
     * @return Number of transactions removed
     */
    size_t performMaintenance();
};

#endif // MEMPOOL_H