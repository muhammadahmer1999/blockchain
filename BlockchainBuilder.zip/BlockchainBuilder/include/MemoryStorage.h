#ifndef MEMORY_STORAGE_H
#define MEMORY_STORAGE_H

#include <string>
#include <vector>
#include <memory>
#include <nlohmann/json.hpp>
#include <leveldb/db.h>
#include <mutex>
#include <map>
#include "../src/wallet.h"

using json = nlohmann::json;

/**
 * @struct Memory
 * @brief Represents a memory (image or text) stored on the blockchain
 */
struct Memory {
    std::string id;                // Unique identifier
    std::string ownerAddress;      // Wallet address of the memory owner
    std::string hash;              // Hash of the memory content
    std::string encryptedContent;  // Encrypted memory content
    std::string contentType;       // Type of memory (image/text)
    std::string category;          // Category of memory (e.g., family, travel, special)
    std::string title;             // Memory title
    std::string description;       // Optional description
    uint64_t timestamp;            // Time when memory was added
    double rewardAmount;           // Amount of coins rewarded
    std::vector<std::string> tags; // Optional tags for searching
    bool isPrivate;                // Whether memory is private or public
    double latitude;               // Optional geo-location data
    double longitude;              // Optional geo-location data
    std::string location;          // Named location (e.g., "Lahore, Pakistan")
};

/**
 * @class MemoryStorage
 * @brief Storage for memories on the blockchain
 */
class MemoryStorage {
public:
    /**
     * Default constructor
     */
    MemoryStorage();
    
    /**
     * Constructor with specific path
     * @param dbPath Path to the database
     */
    explicit MemoryStorage(const std::string& dbPath);
    
    /**
     * Destructor
     */
    ~MemoryStorage();
    
    /**
     * Initialize the storage
     * @param path Path to the database
     * @return True if successful
     */
    bool initialize(const std::string& path);
    
    /**
     * Close the storage
     */
    void close();
    
    /**
     * Store a new memory
     * @param memory Memory to store
     * @param wallet Wallet for encryption
     * @return True if successful
     */
    bool storeMemory(Memory& memory, const Wallet& wallet);
    
    /**
     * Retrieve a memory by ID
     * @param id Memory ID
     * @param wallet Wallet for decryption
     * @return Memory object if found and accessible, empty memory otherwise
     */
    Memory getMemory(const std::string& id, const Wallet& wallet);
    
    /**
     * Check if a memory hash exists (for duplicate detection)
     * @param hash Memory content hash
     * @return True if exists
     */
    bool memoryHashExists(const std::string& hash);
    
    /**
     * Get all memories owned by a wallet address
     * @param walletAddress Wallet address
     * @param wallet Wallet for decryption
     * @return Vector of accessible memories
     */
    std::vector<Memory> getMemoriesByOwner(const std::string& walletAddress, const Wallet& wallet);
    
    /**
     * Get all public memories
     * @return Vector of public memories
     */
    std::vector<Memory> getPublicMemories();
    
    /**
     * Search memories by category
     * @param category The category to search for
     * @param wallet The user's wallet for access control
     * @return Matching memories visible to the user
     */
    std::vector<Memory> searchByCategory(const std::string& category, const Wallet& wallet);
    
    /**
     * Search memories by tags
     * @param tags List of tags to search for
     * @param wallet The user's wallet for access control
     * @return Matching memories visible to the user
     */
    std::vector<Memory> searchByTags(const std::vector<std::string>& tags, const Wallet& wallet);
    
    /**
     * Search memories by location
     * @param location The location name to search for
     * @param wallet The user's wallet for access control
     * @return Matching memories visible to the user
     */
    std::vector<Memory> searchByLocation(const std::string& location, const Wallet& wallet);
    
    /**
     * Search memories by coordinates (proximity)
     * @param latitude Central latitude
     * @param longitude Central longitude
     * @param radiusKm Search radius in kilometers
     * @param wallet The user's wallet for access control
     * @return Matching memories visible to the user
     */
    std::vector<Memory> searchByProximity(double latitude, double longitude, double radiusKm, const Wallet& wallet);
    
    /**
     * Update memory metadata
     * @param id Memory ID
     * @param updatedMemory Updated memory data
     * @param wallet Wallet for verification
     * @return True if update successful
     */
    bool updateMemory(const std::string& id, const Memory& updatedMemory, const Wallet& wallet);
    
    /**
     * Delete a memory
     * @param id Memory ID
     * @param wallet Wallet for verification
     * @return True if deletion successful
     */
    bool deleteMemory(const std::string& id, const Wallet& wallet);
    
private:
    /**
     * Database instance
     */
    std::unique_ptr<leveldb::DB> m_db;
    
    /**
     * Database path
     */
    std::string m_dbPath;
    
    /**
     * Mutex for thread-safe access
     */
    mutable std::mutex m_mutex;
    
    /**
     * Memory prefix for keys
     */
    static const std::string MEMORY_PREFIX;
    
    /**
     * Hash index prefix for keys
     */
    static const std::string HASH_INDEX_PREFIX;
    
    /**
     * Owner index prefix for keys
     */
    static const std::string OWNER_INDEX_PREFIX;
    
    /**
     * Create key for memory
     * @param id Memory ID
     * @return Database key
     */
    std::string memoryKey(const std::string& id) const;
    
    /**
     * Create key for hash index
     * @param hash Memory hash
     * @return Database key
     */
    std::string hashIndexKey(const std::string& hash) const;
    
    /**
     * Create key for owner index
     * @param ownerAddress Owner's wallet address
     * @param id Memory ID
     * @return Database key
     */
    std::string ownerIndexKey(const std::string& ownerAddress, const std::string& id) const;
    
    /**
     * Generate a unique ID for a memory
     * @return Unique ID
     */
    std::string generateUniqueId() const;
    
    /**
     * Encrypt memory content
     * @param content Content to encrypt
     * @param wallet Wallet for encryption
     * @return Encrypted content
     */
    std::string encryptContent(const std::string& content, const Wallet& wallet) const;
    
    /**
     * Decrypt memory content
     * @param encryptedContent Encrypted content
     * @param wallet Wallet for decryption
     * @return Decrypted content
     */
    std::string decryptContent(const std::string& encryptedContent, const Wallet& wallet) const;
    
    /**
     * Check if the wallet is the owner of the memory
     * @param memoryOwnerAddress Memory owner address
     * @param wallet Wallet to check
     * @return True if wallet is the owner
     */
    bool isMemoryOwner(const std::string& memoryOwnerAddress, const Wallet& wallet) const;
};

#endif // MEMORY_STORAGE_H