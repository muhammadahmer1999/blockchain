#ifndef SHARDING_H
#define SHARDING_H

#include "../src/transaction.h"
#include <vector>
#include <mutex>
#include <functional>

/**
 * @class ShardManager
 * @brief Manages transaction sharding for improved scalability
 * 
 * The ShardManager distributes transactions across multiple shards
 * based on wallet addresses to improve transaction processing throughput.
 */
class ShardManager {
public:
    /**
     * Structure to hold shard statistics
     */
    struct ShardStats {
        size_t shardCount;
        size_t totalTransactions;
        std::vector<size_t> transactionsPerShard;
        double balanceRatio;       // Balance ratio between shards (1.0 = perfect balance)
        uint64_t lastRebalanceTime; // Timestamp of last rebalance operation
    };
    
    /**
     * Structure to define shard configuration
     */
    struct ShardConfig {
        bool enableDynamicSharding;     // Enable dynamic shard adjustment
        bool isMainnet;                 // Run in mainnet mode with stricter requirements
        bool enableShardRebalancing;    // Enable rebalancing operations between shards
        uint64_t rebalanceInterval;     // Time interval between rebalance operations (in seconds)
        double targetBalanceRatio;      // Target balance ratio to maintain (0.0-1.0)
        size_t maxTransactionsPerShard; // Maximum transactions per shard before scaling
    };
    
    /**
     * Default constructor - initializes with the default shard count
     */
    ShardManager();
    
    /**
     * Constructor with specified shard count
     * @param shardCount Number of shards to create
     */
    explicit ShardManager(size_t shardCount);
    
    /**
     * Constructor with specified shard count and configuration
     * @param shardCount Number of shards to create
     * @param isMainnet Flag indicating if running in mainnet mode
     */
    ShardManager(size_t shardCount, bool isMainnet);
    
    /**
     * Add a transaction to the appropriate shard
     * @param transaction The transaction to add
     * @return True if successful, false otherwise
     */
    bool addTransaction(const Transaction& transaction);
    
    /**
     * Get all transactions from a specific shard
     * @param shardIndex Index of the shard to retrieve
     * @return Vector of transactions from the specified shard
     */
    std::vector<Transaction> getTransactionsFromShard(size_t shardIndex) const;
    
    /**
     * Get all pending transactions from all shards
     * @param limit Maximum number of transactions to return (0 for no limit)
     * @return Vector of all transactions from all shards
     */
    std::vector<Transaction> getAllTransactions(size_t limit = 0) const;
    
    /**
     * Clear all transactions from a specific shard
     * @param shardIndex Index of the shard to clear
     */
    void clearShard(size_t shardIndex);
    
    /**
     * Clear all transactions from all shards
     */
    void clearAllShards();
    
    /**
     * Get the current number of shards
     * @return Number of shards
     */
    size_t getShardCount() const;
    
    /**
     * Resize the number of shards and redistribute transactions
     * @param newShardCount New number of shards to create
     */
    void resizeShards(size_t newShardCount);
    
    /**
     * Get statistics about the shards
     * @return ShardStats structure with statistics
     */
    ShardStats getShardStatistics() const;
    
    /**
     * Process all shards in parallel
     * @param processor Function to process each shard's transactions
     */
    void processAllShardsInParallel(std::function<void(const std::vector<Transaction>&)> processor);
    
private:
    /**
     * Default number of shards
     */
    static const size_t DEFAULT_SHARD_COUNT;
    
    /**
     * Mutex for thread-safe access to shard data
     */
    static std::mutex s_shardMutex;
    
    /**
     * Number of shards
     */
    size_t m_shardCount;
    
    /**
     * Shard configuration
     */
    ShardConfig m_config;
    
    /**
     * Vector of shards, each containing a vector of transactions
     */
    std::vector<std::vector<Transaction>> m_shards;
    
    /**
     * Initialize the shards array
     */
    void initializeShards();
    
    /**
     * Determine which shard an address belongs to
     * @param address The wallet address
     * @return Shard index for the address
     */
    size_t getShardForAddress(const std::string& address) const;
    
    /**
     * Get a random shard index
     * @return Random shard index
     */
    size_t getRandomShard() const;
};

#endif // SHARDING_H