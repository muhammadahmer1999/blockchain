#pragma once

#include <vector>
#include <string>
#include <memory>
#include "Block.h"
#include "Transaction.h"
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Forward declarations
class IStorage;

class Blockchain {
private:
    std::vector<Block> chain;
    std::vector<Transaction> pendingTransactions;
    unsigned int difficulty;
    double miningReward;
    std::shared_ptr<IStorage> storage;
    
    // Mainnet specific parameters
    bool isMainnet;
    std::string networkId;
    
    // Network parameters
    unsigned int maxBlockSize;     // Maximum size of a block in bytes
    unsigned int maxTransactionsPerBlock; // Maximum number of transactions per block
    unsigned int blockTime;        // Target block time in seconds
    unsigned int halvingInterval;  // Number of blocks between reward halvings
    
public:
    // Constructor
    Blockchain(unsigned int difficulty = 4, double miningReward = 100.0, bool isMainnet = false, const std::string& networkId = "testnet");
    
    // Create genesis block
    void createGenesisBlock();
    
    // Get latest block
    const Block& getLatestBlock() const;
    
    // Mining
    void minePendingTransactions(const std::string& miningRewardAddress);
    
    // Add transaction
    bool addTransaction(const Transaction& transaction);
    
    // Get balance of an address
    double getBalanceOfAddress(const std::string& address) const;
    
    // Chain validation
    bool isChainValid() const;
    
    // Getters
    inline const std::vector<Block>& getChain() const { return chain; }
    inline const std::vector<Transaction>& getPendingTransactions() const { return pendingTransactions; }
    inline unsigned int getDifficulty() const { return difficulty; }
    inline double getMiningReward() const { return miningReward; }
    inline std::shared_ptr<IStorage> getStorage() const { return storage; }
    inline bool getIsMainnet() const { return isMainnet; }
    inline const std::string& getNetworkId() const { return networkId; }
    inline unsigned int getMaxBlockSize() const { return maxBlockSize; }
    inline unsigned int getMaxTransactionsPerBlock() const { return maxTransactionsPerBlock; }
    inline unsigned int getBlockTime() const { return blockTime; }
    inline unsigned int getHalvingInterval() const { return halvingInterval; }
    
    // Setters
    inline void setDifficulty(unsigned int newDifficulty) { difficulty = newDifficulty; }
    inline void setMiningReward(double newReward) { miningReward = newReward; }
    inline void setStorage(std::shared_ptr<IStorage> newStorage) { storage = newStorage; }
    inline void setIsMainnet(bool mainnet) { isMainnet = mainnet; }
    inline void setNetworkId(const std::string& id) { networkId = id; }
    inline void setMaxBlockSize(unsigned int size) { maxBlockSize = size; }
    inline void setMaxTransactionsPerBlock(unsigned int max) { maxTransactionsPerBlock = max; }
    inline void setBlockTime(unsigned int time) { blockTime = time; }
    inline void setHalvingInterval(unsigned int interval) { halvingInterval = interval; }
    
    // Serialize to JSON
    json toJson() const;
    
    // Deserialize from JSON
    static Blockchain fromJson(const json& j);
};
