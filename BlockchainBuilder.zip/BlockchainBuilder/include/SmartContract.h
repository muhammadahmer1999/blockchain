#ifndef SMART_CONTRACT_H
#define SMART_CONTRACT_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// Forward declarations
class Blockchain;
class Transaction;

/**
 * Smart Contract base class
 * Provides a framework for executable logic on the blockchain
 */
class SmartContract {
protected:
    // Contract address (usually a hash of creator's address + nonce)
    std::string address;
    
    // Contract owner
    std::string ownerAddress;
    
    // Contract state data
    json state;
    
    // Contract code (simplified representation as JSON)
    json code;
    
    // Contract creation timestamp
    uint64_t creationTimestamp;

public:
    SmartContract();
    SmartContract(const std::string& owner, const json& contractCode);
    virtual ~SmartContract() = default;
    
    // Initialize contract
    virtual bool initialize(const Blockchain& blockchain);
    
    // Execute contract with transaction input
    virtual json execute(const Transaction& transaction, Blockchain& blockchain);
    
    // Validate transaction conforms to contract rules
    virtual bool validateTransaction(const Transaction& transaction, const Blockchain& blockchain) const;
    
    // Getters
    std::string getAddress() const;
    std::string getOwner() const;
    json getState() const;
    json getCode() const;
    uint64_t getCreationTimestamp() const;
    
    // Serialize to JSON
    virtual json toJson() const;
    
    // Deserialize from JSON
    static std::shared_ptr<SmartContract> fromJson(const json& j);
};

/**
 * Token Contract - A basic token implementation
 * Demonstrates smart contract functionality with token transfers
 */
class TokenContract : public SmartContract {
private:
    std::string tokenName;
    std::string tokenSymbol;
    uint64_t totalSupply;
    std::map<std::string, uint64_t> balances;

public:
    TokenContract(const std::string& owner, 
                 const std::string& name,
                 const std::string& symbol, 
                 uint64_t initialSupply);
    
    // Initialize with token creation
    bool initialize(const Blockchain& blockchain) override;
    
    // Execute token operations (transfer, etc.)
    json execute(const Transaction& transaction, Blockchain& blockchain) override;
    
    // Validate token transactions
    bool validateTransaction(const Transaction& transaction, const Blockchain& blockchain) const override;
    
    // Token specific operations
    bool transfer(const std::string& from, const std::string& to, uint64_t amount);
    uint64_t balanceOf(const std::string& address) const;
    
    // Serialize to JSON
    json toJson() const override;
    
    // Deserialize from JSON
    static std::shared_ptr<TokenContract> fromJson(const json& j);
};

/**
 * Smart Contract Factory
 * Creates and manages different types of smart contracts
 */
class SmartContractFactory {
private:
    // Map of contract types to creation functions
    using ContractCreator = std::function<std::shared_ptr<SmartContract>(const json&)>;
    static std::map<std::string, ContractCreator> contractCreators;
    
public:
    // Register contract types
    static void initialize();
    
    // Create a contract instance by type
    static std::shared_ptr<SmartContract> createContract(const std::string& type, const json& params);
    
    // Register a new contract type
    static void registerContractType(const std::string& type, ContractCreator creator);
};

#endif // SMART_CONTRACT_H