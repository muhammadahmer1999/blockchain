#pragma once

#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <cryptopp/sha.h>
#include <cryptopp/hex.h>

class Utils {
public:
    // SHA256 hash function
    static std::string sha256(const std::string& input);
    
    // Convert byte vector to hex string
    static std::string bytesToHexString(const std::vector<unsigned char>& bytes);
    
    // Convert hex string to byte vector
    static std::vector<unsigned char> hexStringToBytes(const std::string& hex);
    
    // Convert Base64 to string
    static std::string base64Decode(const std::string& input);
    
    // Convert string to Base64
    static std::string base64Encode(const std::string& input);
};
