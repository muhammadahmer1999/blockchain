#pragma once

#include <string>
#include <vector>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

class Transaction {
private:
    std::string fromAddress;
    std::string toAddress;
    double amount;
    std::string signature;
    std::string data; // Smart contract data or other transaction data
    
public:
    // Constructors
    Transaction(); // Default constructor
    Transaction(const std::string& fromAddress, const std::string& toAddress, double amount);
    
    // Calculate transaction hash
    std::string calculateHash() const;
    
    // Sign transaction
    void signTransaction(const std::string& signingKey);
    
    // Verify signature
    bool isValid() const;
    
    // Getters
    inline const std::string& getFromAddress() const { return fromAddress; }
    inline const std::string& getToAddress() const { return toAddress; }
    inline double getAmount() const { return amount; }
    inline const std::string& getSignature() const { return signature; }
    inline const std::string& getData() const { return data; }
    
    // Setters
    inline void setData(const std::string& newData) { data = newData; }
    
    // Serialize to JSON
    json toJson() const;
    
    // Deserialize from JSON
    static Transaction fromJson(const json& j);
};
