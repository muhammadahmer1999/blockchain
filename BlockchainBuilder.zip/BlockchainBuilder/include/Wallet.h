#pragma once

#include <string>
#include <utility>
#include <cryptopp/eccrypto.h>
#include <cryptopp/osrng.h>
#include <cryptopp/oids.h>

class Wallet {
private:
    std::string privateKey;
    std::string publicKey;
    
public:
    // Constructor
    Wallet();
    
    // Generate new key pair
    void generateKeyPair();
    
    // Sign data
    std::string sign(const std::string& data) const;
    
    // Verify signature
    static bool verify(const std::string& publicKey, const std::string& data, const std::string& signature);
    
    // Getters
    inline const std::string& getPrivateKey() const { return privateKey; }
    inline const std::string& getPublicKey() const { return publicKey; }
    
    // Create wallet from existing private key
    static Wallet fromPrivateKey(const std::string& privateKey);
};
