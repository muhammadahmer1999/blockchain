#ifndef STORAGE_H
#define STORAGE_H

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <nlohmann/json.hpp>
#include <leveldb/db.h>
#include <mutex>

using json = nlohmann::json;

// Forward declarations
class Block;
class Blockchain;
class Transaction;
class SmartContract;

/**
 * Storage Interface
 * Abstract base class for blockchain storage systems
 */
class IStorage {
public:
    virtual ~IStorage() = default;
    
    // Open/close database
    virtual bool open(const std::string& path) = 0;
    virtual void close() = 0;
    
    // Blockchain operations
    virtual bool saveBlock(const Block& block) = 0;
    virtual bool getBlock(size_t index, Block& block) = 0;
    virtual bool getBlockByHash(const std::string& hash, Block& block) = 0;
    virtual bool deleteBlock(size_t index) = 0;
    virtual size_t getBlockCount() = 0;
    
    // Transaction operations
    virtual bool saveTransaction(const Transaction& transaction) = 0;
    virtual bool getTransaction(const std::string& hash, Transaction& transaction) = 0;
    virtual bool savePendingTransaction(const Transaction& transaction) = 0;
    virtual std::vector<Transaction> getPendingTransactions(size_t limit = 100) = 0;
    
    // Smart contract operations
    virtual bool saveSmartContract(const std::shared_ptr<SmartContract>& contract) = 0;
    virtual std::shared_ptr<SmartContract> getSmartContract(const std::string& address) = 0;
    
    // Chain state operations
    virtual bool saveChainState(const Blockchain& blockchain) = 0;
    virtual bool loadChainState(Blockchain& blockchain) = 0;
    
    // General key-value operations
    virtual bool put(const std::string& key, const std::string& value) = 0;
    virtual bool get(const std::string& key, std::string& value) = 0;
    virtual bool remove(const std::string& key) = 0;
};

/**
 * LevelDB Storage Implementation
 * Persistent blockchain storage using LevelDB
 */
class LevelDBStorage : public IStorage {
private:
    // LevelDB database instance
    std::unique_ptr<leveldb::DB> db;
    
    // Path to database
    std::string dbPath;
    
    // Thread safety
    std::mutex mutex;
    
    // Key prefixes for different data types
    static const std::string BLOCK_PREFIX;
    static const std::string BLOCK_HASH_PREFIX;
    static const std::string TX_PREFIX; 
    static const std::string PENDING_TX_PREFIX;
    static const std::string CONTRACT_PREFIX;
    static const std::string META_PREFIX;
    
    // Helper methods
    std::string blockKey(size_t index) const;
    std::string blockHashKey(const std::string& hash) const;
    std::string txKey(const std::string& hash) const;
    std::string pendingTxKey(const std::string& hash) const;
    std::string contractKey(const std::string& address) const;
    std::string metaKey(const std::string& key) const;

public:
    LevelDBStorage();
    virtual ~LevelDBStorage();
    
    // Implementation of IStorage interface
    bool open(const std::string& path) override;
    void close() override;
    
    bool saveBlock(const Block& block) override;
    bool getBlock(size_t index, Block& block) override;
    bool getBlockByHash(const std::string& hash, Block& block) override;
    bool deleteBlock(size_t index) override;
    size_t getBlockCount() override;
    
    bool saveTransaction(const Transaction& transaction) override;
    bool getTransaction(const std::string& hash, Transaction& transaction) override;
    bool savePendingTransaction(const Transaction& transaction) override;
    std::vector<Transaction> getPendingTransactions(size_t limit = 100) override;
    
    bool saveSmartContract(const std::shared_ptr<SmartContract>& contract) override;
    std::shared_ptr<SmartContract> getSmartContract(const std::string& address) override;
    
    bool saveChainState(const Blockchain& blockchain) override;
    bool loadChainState(Blockchain& blockchain) override;
    
    bool put(const std::string& key, const std::string& value) override;
    bool get(const std::string& key, std::string& value) override;
    bool remove(const std::string& key) override;
    
    // Additional LevelDB specific methods
    bool batch(const std::vector<std::pair<std::string, std::string>>& operations);
    void iterate(const std::string& prefix, 
                std::function<bool(const std::string&, const std::string&)> callback);
};

#endif // STORAGE_H