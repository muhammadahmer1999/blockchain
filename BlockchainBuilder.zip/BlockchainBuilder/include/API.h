#ifndef API_H
#define API_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <mutex>
#include <memory>
#include <nlohmann/json.hpp>

// Forward declarations
class Blockchain;
class Transaction;
class Block;
class Storage;

using json = nlohmann::json;

/**
 * @class APIServer
 * @brief RESTful API server for the blockchain
 * 
 * The APIServer provides HTTP endpoints for interacting with the blockchain
 * from external applications.
 */
class APIServer {
public:
    /**
     * Constructor
     * @param blockchain Reference to the blockchain instance
     * @param port Port to run the server on (default: 8080)
     */
    explicit APIServer(Blockchain& blockchain, int port = 8080);
    
    /**
     * Destructor
     */
    ~APIServer();
    
    /**
     * Start the API server
     * @return True if started successfully, false otherwise
     */
    bool start();
    
    /**
     * Stop the API server
     */
    void stop();
    
    /**
     * Check if the server is running
     * @return True if running, false otherwise
     */
    bool isRunning() const;
    
    /**
     * Get the port the server is running on
     * @return Port number
     */
    int getPort() const;
    
    /**
     * Set CORS (Cross-Origin Resource Sharing) settings
     * @param allowedOrigins Comma-separated list of allowed origins
     */
    void setCORSSettings(const std::string& allowedOrigins);
    
    /**
     * Enable or disable HTTPS
     * @param enabled Whether to enable HTTPS
     * @param certFile Path to the certificate file
     * @param keyFile Path to the key file
     */
    void setHTTPS(bool enabled, const std::string& certFile = "", const std::string& keyFile = "");
    
    /**
     * Handle API requests (used by the underlying server implementation)
     * @param route The API route being requested
     * @param method The HTTP method (GET, POST, etc.)
     * @param params Query parameters
     * @param body Request body
     * @return Response data as JSON
     */
    json handleRequest(const std::string& route, const std::string& method, 
                      const std::map<std::string, std::string>& params,
                      const std::string& body);
    
private:
    /**
     * Handle GET /blockchain/info
     * @return Information about the blockchain
     */
    json handleGetBlockchainInfo();
    
    /**
     * Handle GET /blocks
     * @param params Query parameters
     * @return List of blocks (with optional start/limit)
     */
    json handleGetBlocks(const std::map<std::string, std::string>& params);
    
    /**
     * Handle GET /blocks/:index
     * @param params Query parameters (including index)
     * @return Block data
     */
    json handleGetBlock(const std::map<std::string, std::string>& params);
    
    /**
     * Handle GET /transactions
     * @param params Query parameters
     * @return List of transactions
     */
    json handleGetTransactions(const std::map<std::string, std::string>& params);
    
    /**
     * Handle GET /transactions/:hash
     * @param params Query parameters (including hash)
     * @return Transaction data
     */
    json handleGetTransaction(const std::map<std::string, std::string>& params);
    
    /**
     * Handle POST /transactions
     * @param body Request body (transaction data)
     * @return Status of the transaction submission
     */
    json handleCreateTransaction(const std::string& body);
    
    /**
     * Handle GET /mempool
     * @return Information about pending transactions
     */
    json handleGetMempool();
    
    /**
     * Handle GET /balance/:address
     * @param params Query parameters (including address)
     * @return Balance for the specified address
     */
    json handleGetBalance(const std::map<std::string, std::string>& params);
    
    /**
     * Handle POST /mine
     * @param body Request body (mining data)
     * @return Mining result
     */
    json handleMineBlock(const std::string& body);
    
    /**
     * Handle GET /peers
     * @return List of connected peers
     */
    json handleGetPeers();
    
    /**
     * Handle POST /peers
     * @param body Request body (peer data)
     * @return Status of the peer connection
     */
    json handleAddPeer(const std::string& body);
    
    /**
     * Reference to the blockchain
     */
    Blockchain& m_blockchain;
    
    /**
     * Server port
     */
    int m_port;
    
    /**
     * Flag indicating if the server is running
     */
    bool m_running;
    
    /**
     * CORS settings
     */
    std::string m_corsAllowedOrigins;
    
    /**
     * HTTPS settings
     */
    bool m_httpsEnabled;
    std::string m_certFile;
    std::string m_keyFile;
    
    /**
     * Mutex for thread safety
     */
    mutable std::mutex m_mutex;
    
    /**
     * Pointer to the server implementation (pimpl pattern)
     */
    class ServerImpl;
    std::unique_ptr<ServerImpl> m_impl;
};

#endif // API_H