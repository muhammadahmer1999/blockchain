#pragma once

#include <string>
#include <vector>
#include <ctime>
#include <sstream>
#include "Transaction.h"
#include <nlohmann/json.hpp>

using json = nlohmann::json;

class Block {
private:
    unsigned int index;
    time_t timestamp;
    std::vector<Transaction> transactions;
    std::string previousHash;
    std::string hash;
    unsigned int nonce;
    
public:
    // Constructor
    Block(unsigned int index, const std::string& previousHash, const std::vector<Transaction>& transactions);
    
    // Calculate hash
    void mineBlock(unsigned int difficulty);
    
    // Calculate the hash of the block
    std::string calculateHash() const;
    
    // Getters
    inline const std::string& getHash() const { return hash; }
    inline const std::string& getPreviousHash() const { return previousHash; }
    inline unsigned int getIndex() const { return index; }
    inline time_t getTimestamp() const { return timestamp; }
    inline const std::vector<Transaction>& getTransactions() const { return transactions; }
    inline unsigned int getNonce() const { return nonce; }
    
    // Validate block's transactions
    bool hasValidTransactions() const;
    
    // Serialize to JSON
    json toJson() const;
    
    // Deserialize from JSON
    static Block fromJson(const json& j);
};
