/**
 * @file transaction.cpp
 * @brief Implementation of the Transaction class
 */

#include "transaction.h"
#include "utils.h"
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cryptopp/eccrypto.h>
#include <cryptopp/oids.h>
#include <cryptopp/osrng.h>
#include <cryptopp/hex.h>

Transaction::Transaction()
    : m_fromAddress(""),
      m_toAddress(""),
      m_amount(0.0),
      m_timestamp(std::chrono::system_clock::now()) {
}

Transaction::Transaction(const std::string& fromAddress, 
                         const std::string& toAddress, 
                         double amount)
    : m_fromAddress(fromAddress),
      m_toAddress(toAddress),
      m_amount(amount),
      m_timestamp(std::chrono::system_clock::now()) {
}

std::string Transaction::calculateHash() const {
    std::stringstream ss;
    ss << m_fromAddress << m_toAddress << std::fixed << std::setprecision(8) << m_amount 
       << Utils::timePointToString(m_timestamp);
    
    return Utils::sha256(ss.str());
}

void Transaction::signTransaction(const std::vector<uint8_t>& signingKey) {
    // If it's a mining reward, we don't sign it
    if (m_fromAddress.empty()) {
        return;
    }
    
    try {
        // Calculate the hash of this transaction
        std::string txHash = calculateHash();
        
        // In a real implementation, we would use the private key to sign the transaction hash
        // For simplicity, we'll just create a dummy signature based on the key and hash
        std::string signature = Utils::signMessage(txHash, signingKey);
        m_signature = signature;
    } catch (const std::exception& e) {
        std::cerr << "Error signing transaction: " << e.what() << std::endl;
        throw;
    }
}

bool Transaction::isValid() const {
    // Mining rewards don't need validation as they have no sender
    if (m_fromAddress.empty()) {
        return true;
    }
    
    // Check if the transaction has a signature
    if (m_signature.empty()) {
        std::cerr << "No signature in this transaction" << std::endl;
        return false;
    }
    
    // In a real implementation, we would verify the signature using the public key
    // For simplicity, we'll assume the transaction is valid if it has a non-empty signature
    return !m_signature.empty();
}

const std::string& Transaction::getFromAddress() const {
    return m_fromAddress;
}

const std::string& Transaction::getToAddress() const {
    return m_toAddress;
}

double Transaction::getAmount() const {
    return m_amount;
}

std::chrono::system_clock::time_point Transaction::getTimestamp() const {
    return m_timestamp;
}

const std::string& Transaction::getSignature() const {
    return m_signature;
}

void Transaction::setSignature(const std::string& signature) {
    m_signature = signature;
}

std::string Transaction::toString() const {
    std::stringstream ss;
    ss << "From: " << (m_fromAddress.empty() ? "SYSTEM (Mining Reward)" : m_fromAddress) << "\n"
       << "To: " << m_toAddress << "\n"
       << "Amount: " << std::fixed << std::setprecision(8) << m_amount << "\n"
       << "Time: " << Utils::timePointToString(m_timestamp) << "\n";
    
    return ss.str();
}
