/**
 * @file transaction.h
 * @brief Definition of the Transaction class
 */

#pragma once

#include <string>
#include <chrono>
#include <vector>

/**
 * @class Transaction
 * @brief Represents a transaction in the blockchain
 */
class Transaction {
public:
    /**
     * @brief Default constructor for Transaction
     */
    Transaction();

    /**
     * @brief Constructor for a new Transaction
     * @param fromAddress The address of the sender
     * @param toAddress The address of the recipient
     * @param amount The amount to transfer
     */
    Transaction(const std::string& fromAddress, 
                const std::string& toAddress, 
                double amount);

    /**
     * @brief Calculate transaction hash
     * @return SHA256 hash of the transaction
     */
    std::string calculateHash() const;

    /**
     * @brief Sign the transaction with a signing key
     * @param signingKey The key to sign the transaction
     */
    void signTransaction(const std::vector<uint8_t>& signingKey);

    /**
     * @brief Check if the transaction is valid
     * @return true if the transaction is valid
     */
    bool isValid() const;

    /**
     * @brief Get the sender's address
     * @return The from address
     */
    const std::string& getFromAddress() const;

    /**
     * @brief Get the recipient's address
     * @return The to address
     */
    const std::string& getToAddress() const;

    /**
     * @brief Get the transaction amount
     * @return The amount
     */
    double getAmount() const;

    /**
     * @brief Get the transaction timestamp
     * @return The timestamp
     */
    std::chrono::system_clock::time_point getTimestamp() const;

    /**
     * @brief Get the transaction signature
     * @return The signature
     */
    const std::string& getSignature() const;
    
    /**
     * @brief Set the transaction signature
     * @param signature The signature to set
     */
    void setSignature(const std::string& signature);

    /**
     * @brief String representation of the transaction
     * @return String with transaction details
     */
    std::string toString() const;

private:
    std::string m_fromAddress;
    std::string m_toAddress;
    double m_amount;
    std::chrono::system_clock::time_point m_timestamp;
    std::string m_signature;
};
