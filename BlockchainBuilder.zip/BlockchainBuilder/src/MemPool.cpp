#include "../include/MemPool.h"
#include "../src/utils.h"
#include <iostream>
#include <algorithm>
#include <sstream>
#include <iomanip>

MemPool::MemPool() : m_currentSizeBytes(0) {
    // Configure for testnet
    m_config = {
        .isMainnet = false,
        .maxTransactions = 5000,            // 5,000 transactions
        .maxSizeBytes = 20 * 1024 * 1024,   // 20 MB mempool size
        .minFeeRate = 1,                    // 1 satoshi per byte
        .maxTransactionAge = 72 * 3600,     // 72 hours (3 days)
        .prioritizeBySizeAndFee = false,    // Simple priority
        .enableRBF = false,                 // No replace-by-fee
        .cleanupIntervalSeconds = 3600      // 1 hour cleanup
    };
    
    // Initialize cleanup time
    m_lastCleanupTime = std::chrono::system_clock::now();
    
    std::cout << "Initialized MemPool in TESTNET mode" << std::endl;
}

MemPool::MemPool(bool isMainnet) : m_currentSizeBytes(0) {
    if (isMainnet) {
        // Configure for mainnet (stricter and more optimized)
        m_config = {
            .isMainnet = true,
            .maxTransactions = 15000,           // 15,000 transactions
            .maxSizeBytes = 300 * 1024 * 1024,  // 300 MB mempool size
            .minFeeRate = 5,                    // 5 satoshi per byte
            .maxTransactionAge = 14 * 24 * 3600, // 14 days
            .prioritizeBySizeAndFee = true,     // Prioritize by fee per byte
            .enableRBF = true,                  // Enable replace-by-fee
            .cleanupIntervalSeconds = 900       // 15 min cleanup
        };
        
        std::cout << "Initialized MemPool in MAINNET mode with optimized settings" << std::endl;
    } else {
        // Configure for testnet
        m_config = {
            .isMainnet = false,
            .maxTransactions = 5000,            // 5,000 transactions
            .maxSizeBytes = 20 * 1024 * 1024,   // 20 MB mempool size
            .minFeeRate = 1,                    // 1 satoshi per byte
            .maxTransactionAge = 72 * 3600,     // 72 hours (3 days)
            .prioritizeBySizeAndFee = false,    // Simple priority
            .enableRBF = false,                 // No replace-by-fee
            .cleanupIntervalSeconds = 3600      // 1 hour cleanup
        };
        
        std::cout << "Initialized MemPool in TESTNET mode" << std::endl;
    }
    
    // Initialize cleanup time
    m_lastCleanupTime = std::chrono::system_clock::now();
}

bool MemPool::addTransaction(const Transaction& transaction) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    // Perform periodic maintenance (expired transactions, size limit enforcement)
    performMaintenance();
    
    // Generate transaction hash
    std::string txHash = generateTxHash(transaction);
    
    // Check if transaction already exists
    auto existingTx = m_transactions.find(txHash);
    if (existingTx != m_transactions.end()) {
        // If in mainnet mode and RBF is enabled, check if this is a higher fee replacement
        if (m_config.isMainnet && m_config.enableRBF) {
            // Calculate fee for new transaction (simplified calculation)
            double newFee = 0.001 * transaction.getAmount();
            
            // If new fee is higher, replace the transaction (Replace-By-Fee)
            if (newFee > existingTx->second->fee) {
                std::cout << "Replacing transaction with higher fee version: " << txHash << std::endl;
                existingTx->second->transaction = transaction;
                existingTx->second->fee = newFee;
                existingTx->second->addedTime = std::chrono::system_clock::now();
                return true;
            }
        }
        
        std::cout << "Transaction already exists in mempool: " << txHash << std::endl;
        return false;
    }
    
    // Calculate transaction size
    size_t txSize = calculateTxSize(transaction);
    
    // Calculate fee (simplified - in a real implementation this would be more complex)
    // For now, using 0.001 * amount as the fee
    double fee = 0.001 * transaction.getAmount();
    
    // Check if fee meets minimum requirements for mainnet
    if (m_config.isMainnet) {
        double feePerByte = txSize > 0 ? (fee * 100000000) / txSize : 0;
        if (feePerByte < m_config.minFeeRate) {
            std::cout << "Transaction rejected: fee too low (" 
                      << std::fixed << std::setprecision(2) << feePerByte 
                      << " sat/byte, minimum: " << m_config.minFeeRate << ")" << std::endl;
            return false;
        }
    }
    
    // Check if mempool is full
    if (m_transactions.size() >= m_config.maxTransactions) {
        std::cout << "Mempool full, rejecting transaction" << std::endl;
        return false;
    }
    
    // Create transaction entry
    auto entry = std::make_shared<TxEntry>();
    entry->transaction = transaction;
    entry->status = TxStatus::PENDING;
    entry->addedTime = std::chrono::system_clock::now();
    entry->fee = fee;
    entry->feePerByte = txSize > 0 ? (fee * 100000000) / txSize : 0;
    entry->priority = calculateTxPriority(transaction, fee);
    entry->sourceNode = "local"; // In a real implementation, this would be the node ID
    
    // Add to mempool
    m_transactions[txHash] = entry;
    
    // Update mempool size tracking
    m_currentSizeBytes += txSize;
    
    // Log different details based on mode
    if (m_config.isMainnet) {
        std::cout << "Added transaction to mainnet mempool: " << txHash 
                  << " (priority: " << entry->priority
                  << ", fee: " << std::fixed << std::setprecision(8) << fee
                  << ", fee rate: " << std::setprecision(2) << entry->feePerByte
                  << " sat/byte)" << std::endl;
    } else {
        std::cout << "Added transaction to testnet mempool: " << txHash << std::endl;
    }
    
    return true;
}

bool MemPool::removeTransaction(const std::string& txHash) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto it = m_transactions.find(txHash);
    if (it == m_transactions.end()) {
        return false;
    }
    
    m_transactions.erase(it);
    std::cout << "Removed transaction from mempool: " << txHash << std::endl;
    return true;
}

std::shared_ptr<MemPool::TxEntry> MemPool::getTransaction(const std::string& txHash) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto it = m_transactions.find(txHash);
    if (it == m_transactions.end()) {
        return nullptr;
    }
    
    return it->second;
}

std::vector<MemPool::TxEntry> MemPool::getTransactionsByStatus(TxStatus status) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::vector<TxEntry> result;
    
    for (const auto& pair : m_transactions) {
        if (pair.second->status == status) {
            result.push_back(*(pair.second));
        }
    }
    
    return result;
}

std::vector<Transaction> MemPool::getPendingTransactions(size_t limit) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::vector<Transaction> result;
    
    // First, collect all pending transactions
    std::vector<std::shared_ptr<TxEntry>> pendingTxs;
    for (const auto& pair : m_transactions) {
        if (pair.second->status == TxStatus::PENDING) {
            pendingTxs.push_back(pair.second);
        }
    }
    
    // Sort by fee (highest fee first), then by time (oldest first)
    std::sort(pendingTxs.begin(), pendingTxs.end(), 
        [](const std::shared_ptr<TxEntry>& a, const std::shared_ptr<TxEntry>& b) {
            if (a->fee != b->fee) {
                return a->fee > b->fee;
            }
            return a->addedTime < b->addedTime;
        });
    
    // Take the top 'limit' transactions
    size_t count = 0;
    for (const auto& entry : pendingTxs) {
        result.push_back(entry->transaction);
        count++;
        
        if (limit > 0 && count >= limit) {
            break;
        }
    }
    
    return result;
}

bool MemPool::updateTransactionStatus(const std::string& txHash, TxStatus status) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto it = m_transactions.find(txHash);
    if (it == m_transactions.end()) {
        return false;
    }
    
    it->second->status = status;
    
    std::cout << "Updated transaction status: " << txHash << " -> ";
    switch (status) {
        case TxStatus::PENDING:
            std::cout << "PENDING";
            break;
        case TxStatus::PROCESSING:
            std::cout << "PROCESSING";
            break;
        case TxStatus::INVALID:
            std::cout << "INVALID";
            break;
        case TxStatus::CONFIRMED:
            std::cout << "CONFIRMED";
            break;
    }
    std::cout << std::endl;
    
    return true;
}

size_t MemPool::getTransactionCount(TxStatus status) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (status == TxStatus::PENDING) {
        size_t count = 0;
        for (const auto& pair : m_transactions) {
            if (pair.second->status == status) {
                count++;
            }
        }
        return count;
    }
    
    return m_transactions.size();
}

void MemPool::clear() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    m_transactions.clear();
    std::cout << "Cleared all transactions from mempool" << std::endl;
}

size_t MemPool::pruneOldTransactions(const std::chrono::system_clock::time_point& cutoffTime) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    size_t count = 0;
    auto it = m_transactions.begin();
    while (it != m_transactions.end()) {
        if (it->second->addedTime < cutoffTime) {
            it = m_transactions.erase(it);
            count++;
        } else {
            ++it;
        }
    }
    
    if (count > 0) {
        std::cout << "Pruned " << count << " old transactions from mempool" << std::endl;
    }
    
    return count;
}

void MemPool::processTransactions(std::function<void(const Transaction&)> processor, size_t limit) {
    std::vector<Transaction> transactions = getPendingTransactions(limit);
    
    for (const auto& tx : transactions) {
        // Mark as processing
        std::string txHash = generateTxHash(tx);
        updateTransactionStatus(txHash, TxStatus::PROCESSING);
        
        try {
            // Process the transaction
            processor(tx);
            
            // Mark as confirmed (in reality, this would happen after mining)
            updateTransactionStatus(txHash, TxStatus::CONFIRMED);
        } catch (const std::exception& e) {
            // Mark as invalid if processing fails
            std::cerr << "Error processing transaction: " << e.what() << std::endl;
            updateTransactionStatus(txHash, TxStatus::INVALID);
        }
    }
}

std::string MemPool::generateTxHash(const Transaction& transaction) const {
    // Generate hash from transaction data
    std::string txData = transaction.getFromAddress() + transaction.getToAddress() + 
                         std::to_string(transaction.getAmount()) + 
                         Utils::timePointToString(transaction.getTimestamp());
    
    return Utils::sha256(txData);
}

size_t MemPool::calculateTxSize(const Transaction& transaction) const {
    // Simplified size calculation (in reality, this would be more complex)
    // Basic transaction size: 180 bytes (based on typical Bitcoin tx size)
    size_t baseSize = 180;
    
    // Add size based on address lengths (approximation)
    baseSize += transaction.getFromAddress().length();
    baseSize += transaction.getToAddress().length();
    
    // Add size for signature
    baseSize += transaction.getSignature().length();
    
    return baseSize;
}

size_t MemPool::calculateTxPriority(const Transaction& transaction, double fee) const {
    // If in mainnet mode and prioritizing by size and fee
    if (m_config.isMainnet && m_config.prioritizeBySizeAndFee) {
        // Calculate fee per byte (satoshis per byte)
        size_t txSize = calculateTxSize(transaction);
        double feePerByte = txSize > 0 ? (fee * 100000000) / txSize : 0;
        
        // Priority based on fee per byte (higher fee per byte = higher priority)
        return static_cast<size_t>(feePerByte * 1000); // Scale up for integer comparison
    } else {
        // Simple priority based on fee amount only
        return static_cast<size_t>(fee * 1000);
    }
}

size_t MemPool::performMaintenance() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto now = std::chrono::system_clock::now();
    auto lastCleanupDuration = std::chrono::duration_cast<std::chrono::seconds>(
        now - m_lastCleanupTime).count();
        
    // Only perform maintenance if enough time has passed
    if (lastCleanupDuration < m_config.cleanupIntervalSeconds) {
        return 0;
    }
    
    std::cout << "Performing mempool maintenance..." << std::endl;
    
    // Track removed transactions
    size_t removedCount = 0;
    
    // 1. Remove expired transactions
    auto cutoffTime = now - std::chrono::seconds(m_config.maxTransactionAge);
    auto it = m_transactions.begin();
    while (it != m_transactions.end()) {
        if (it->second->addedTime < cutoffTime) {
            // Transaction is too old
            std::cout << "Expiring transaction: " << it->first << " (age: " 
                      << std::chrono::duration_cast<std::chrono::hours>(
                          now - it->second->addedTime).count() 
                      << " hours)" << std::endl;
            it = m_transactions.erase(it);
            removedCount++;
        } else {
            ++it;
        }
    }
    
    // 2. If still over size limit, remove lowest priority transactions
    if (m_transactions.size() > m_config.maxTransactions) {
        std::cout << "Mempool over max transaction count, pruning low priority transactions" << std::endl;
        
        // Collect all transactions with priority
        std::vector<std::pair<std::string, size_t>> txsByPriority;
        for (const auto& [hash, entry] : m_transactions) {
            size_t priority = calculateTxPriority(entry->transaction, entry->fee);
            txsByPriority.push_back({hash, priority});
        }
        
        // Sort by priority (lowest first)
        std::sort(txsByPriority.begin(), txsByPriority.end(), 
            [](const auto& a, const auto& b) {
                return a.second < b.second;
            });
        
        // Remove lowest priority transactions until under limit
        size_t toRemove = m_transactions.size() - m_config.maxTransactions;
        for (size_t i = 0; i < toRemove && i < txsByPriority.size(); i++) {
            m_transactions.erase(txsByPriority[i].first);
            removedCount++;
        }
    }
    
    // Update maintenance time
    m_lastCleanupTime = now;
    
    if (removedCount > 0) {
        std::cout << "Maintenance complete: removed " << removedCount << " transactions" << std::endl;
    } else {
        std::cout << "Maintenance complete: no transactions removed" << std::endl;
    }
    
    return removedCount;
}