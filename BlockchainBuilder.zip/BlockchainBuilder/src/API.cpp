#include "../include/API.h"
#include "../src/blockchain.h"
#include "../src/transaction.h"
#include "../src/block.h"
#include "../src/wallet.h"
#include "../src/utils.h"
#include "../include/Storage.h"
#include <iostream>
#include <sstream>
#include <thread>
#include <curl/curl.h>
#include <chrono>
#include <ctime>

// Helper function to convert time_point to string
std::string timePointToString(const std::chrono::system_clock::time_point& tp) {
    auto time = std::chrono::system_clock::to_time_t(tp);
    std::string ts = std::ctime(&time);
    // Remove newline character from the end
    if (!ts.empty() && ts[ts.length()-1] == '\n') {
        ts.erase(ts.length()-1);
    }
    return ts;
}

// Forward declaration of the implementation
class APIServer::ServerImpl {
public:
    ServerImpl(APIServer& server, Blockchain& blockchain, int port)
        : m_server(server), m_blockchain(blockchain), m_port(port), m_running(false), m_thread() {}
    
    ~ServerImpl() {
        stop();
    }
    
    // Start the server in a new thread
    bool start() {
        if (m_running) {
            return true; // Already running
        }
        
        m_running = true;
        
        // Start server in a new thread
        m_thread = std::thread([this]() {
            std::cout << "API server starting on port " << m_port << std::endl;
            
            // In a real implementation, this would use a proper HTTP server library
            // like cpp-httplib, Crow, or a C++ wrapper for a web server
            
            // For now, we'll just simulate the server loop
            while (m_running) {
                // Simulated server loop - in a real implementation, 
                // this would listen for and process HTTP requests
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            
            std::cout << "API server stopped" << std::endl;
        });
        
        // Give the server thread a moment to start
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        
        return true;
    }
    
    // Stop the server
    void stop() {
        if (!m_running) {
            return; // Not running
        }
        
        // Signal the server thread to stop
        m_running = false;
        
        // Wait for the thread to finish
        if (m_thread.joinable()) {
            m_thread.join();
        }
    }
    
    // Server state accessors
    bool isRunning() const { return m_running; }
    int getPort() const { return m_port; }
    
private:
    APIServer& m_server;             // Reference to the public server interface
    Blockchain& m_blockchain;        // Reference to the blockchain
    int m_port;                      // Server port
    bool m_running;                  // Running state
    std::thread m_thread;            // Server thread
};

// APIServer implementation

APIServer::APIServer(Blockchain& blockchain, int port)
    : m_blockchain(blockchain), m_port(port), m_running(false),
      m_corsAllowedOrigins("*"), m_httpsEnabled(false) {
    // Create the implementation
    m_impl = std::make_unique<ServerImpl>(*this, blockchain, port);
}

APIServer::~APIServer() {
    // Stop the server if it's running
    stop();
}

bool APIServer::start() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (m_impl->isRunning()) {
        return true; // Already running
    }
    
    bool success = m_impl->start();
    m_running = success;
    
    return success;
}

void APIServer::stop() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (!m_impl->isRunning()) {
        return; // Not running
    }
    
    m_impl->stop();
    m_running = false;
}

bool APIServer::isRunning() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_running;
}

int APIServer::getPort() const {
    return m_port;
}

void APIServer::setCORSSettings(const std::string& allowedOrigins) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_corsAllowedOrigins = allowedOrigins;
}

void APIServer::setHTTPS(bool enabled, const std::string& certFile, const std::string& keyFile) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    m_httpsEnabled = enabled;
    m_certFile = certFile;
    m_keyFile = keyFile;
    
    // In a real implementation, the server would need to be restarted
    // to apply the new HTTPS settings
}

json APIServer::handleRequest(const std::string& route, const std::string& method, 
                             const std::map<std::string, std::string>& params,
                             const std::string& body) {
    // Route API requests to the appropriate handler
    
    // Default response for unknown routes
    json errorResponse;
    errorResponse["status"] = "error";
    errorResponse["message"] = "Unknown route: " + route;
    
    try {
        // Blockchain info
        if (route == "/blockchain/info" && method == "GET") {
            return handleGetBlockchainInfo();
        }
        
        // Blocks
        else if (route == "/blocks" && method == "GET") {
            return handleGetBlocks(params);
        }
        else if (route.find("/blocks/") == 0 && method == "GET") {
            return handleGetBlock(params);
        }
        
        // Transactions
        else if (route == "/transactions" && method == "GET") {
            return handleGetTransactions(params);
        }
        else if (route == "/transactions" && method == "POST") {
            return handleCreateTransaction(body);
        }
        else if (route.find("/transactions/") == 0 && method == "GET") {
            return handleGetTransaction(params);
        }
        
        // Mempool
        else if (route == "/mempool" && method == "GET") {
            return handleGetMempool();
        }
        
        // Balance
        else if (route.find("/balance/") == 0 && method == "GET") {
            return handleGetBalance(params);
        }
        
        // Mining
        else if (route == "/mine" && method == "POST") {
            return handleMineBlock(body);
        }
        
        // Peers
        else if (route == "/peers" && method == "GET") {
            return handleGetPeers();
        }
        else if (route == "/peers" && method == "POST") {
            return handleAddPeer(body);
        }
    }
    catch (const std::exception& e) {
        errorResponse["status"] = "error";
        errorResponse["message"] = std::string("Exception: ") + e.what();
    }
    
    return errorResponse;
}

// API endpoint handlers

json APIServer::handleGetBlockchainInfo() {
    json response;
    
    response["status"] = "success";
    json dataObj;
    dataObj["name"] = "Ahmiyat Blockchain";
    dataObj["version"] = "1.0.0";
    dataObj["difficulty"] = m_blockchain.getDifficulty();
    dataObj["blockHeight"] = m_blockchain.getChain().size();
    dataObj["miningReward"] = m_blockchain.getMiningReward();
    dataObj["pendingTransactions"] = m_blockchain.getPendingTransactions().size();
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleGetBlocks(const std::map<std::string, std::string>& params) {
    const auto& chain = m_blockchain.getChain();
    
    // Parse parameters
    size_t start = 0;
    size_t limit = chain.size();
    
    if (params.find("start") != params.end()) {
        start = std::stoul(params.at("start"));
    }
    
    if (params.find("limit") != params.end()) {
        limit = std::stoul(params.at("limit"));
    }
    
    // Ensure start and limit are valid
    start = std::min(start, chain.size());
    limit = std::min(limit, chain.size() - start);
    
    // Build response
    json response;
    json blocksArray = json::array();
    
    for (size_t i = start; i < start + limit; i++) {
        const Block& block = chain[i];
        
        json blockJson;
        blockJson["index"] = block.getIndex();
        blockJson["timestamp"] = timePointToString(block.getTimestamp());
        blockJson["hash"] = block.getHash();
        blockJson["previousHash"] = block.getPreviousHash();
        blockJson["nonce"] = block.getNonce();
        blockJson["transactionCount"] = block.getTransactions().size();
        
        blocksArray.push_back(blockJson);
    }
    
    response["status"] = "success";
    json dataObj;
    dataObj["blocks"] = blocksArray;
    dataObj["total"] = chain.size();
    dataObj["start"] = start;
    dataObj["limit"] = limit;
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleGetBlock(const std::map<std::string, std::string>& params) {
    // Extract block index or hash from the route
    if (params.find("index") == params.end() && params.find("hash") == params.end()) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = "Block index or hash is required";
        return errorResponse;
    }
    
    const auto& chain = m_blockchain.getChain();
    
    // Find block by index or hash
    Block block;
    
    if (params.find("index") != params.end()) {
        size_t index = std::stoul(params.at("index"));
        
        if (index >= chain.size()) {
            json errorResponse;
            errorResponse["status"] = "error";
            errorResponse["message"] = "Block index out of range";
            return errorResponse;
        }
        
        block = chain[index];
    }
    else if (params.find("hash") != params.end()) {
        std::string hash = params.at("hash");
        
        // Find block by hash
        bool found = false;
        for (const auto& b : chain) {
            if (b.getHash() == hash) {
                block = b;
                found = true;
                break;
            }
        }
        
        if (!found) {
            json errorResponse;
            errorResponse["status"] = "error";
            errorResponse["message"] = "Block with hash " + hash + " not found";
            return errorResponse;
        }
    }
    
    // Build response
    json transactionsArray = json::array();
    
    for (const auto& tx : block.getTransactions()) {
        json txJson;
        txJson["fromAddress"] = tx.getFromAddress();
        txJson["toAddress"] = tx.getToAddress();
        txJson["amount"] = tx.getAmount();
        txJson["timestamp"] = timePointToString(tx.getTimestamp());
        
        transactionsArray.push_back(txJson);
    }
    
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["index"] = block.getIndex();
    dataObj["timestamp"] = timePointToString(block.getTimestamp());
    dataObj["hash"] = block.getHash();
    dataObj["previousHash"] = block.getPreviousHash();
    dataObj["nonce"] = block.getNonce();
    dataObj["transactions"] = transactionsArray;
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleGetTransactions(const std::map<std::string, std::string>& params) {
    // Get transactions from all blocks
    std::vector<Transaction> allTransactions;
    
    for (const auto& block : m_blockchain.getChain()) {
        const auto& blockTxs = block.getTransactions();
        allTransactions.insert(allTransactions.end(), blockTxs.begin(), blockTxs.end());
    }
    
    // Parse parameters
    size_t start = 0;
    size_t limit = allTransactions.size();
    
    if (params.find("start") != params.end()) {
        start = std::stoul(params.at("start"));
    }
    
    if (params.find("limit") != params.end()) {
        limit = std::stoul(params.at("limit"));
    }
    
    // Filter by address if provided
    std::string address;
    if (params.find("address") != params.end()) {
        address = params.at("address");
    }
    
    // Build response
    json transactionsArray = json::array();
    size_t count = 0;
    
    for (size_t i = start; i < allTransactions.size() && count < limit; i++) {
        const Transaction& tx = allTransactions[i];
        
        // Filter by address if specified
        if (!address.empty() && tx.getFromAddress() != address && tx.getToAddress() != address) {
            continue;
        }
        
        json txJson;
        txJson["fromAddress"] = tx.getFromAddress();
        txJson["toAddress"] = tx.getToAddress();
        txJson["amount"] = tx.getAmount();
        txJson["timestamp"] = timePointToString(tx.getTimestamp());
        
        transactionsArray.push_back(txJson);
        count++;
    }
    
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["transactions"] = transactionsArray;
    dataObj["total"] = allTransactions.size();
    dataObj["filtered"] = count;
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleGetTransaction(const std::map<std::string, std::string>& params) {
    // Extract transaction hash
    if (params.find("hash") == params.end()) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = "Transaction hash is required";
        return errorResponse;
    }
    
    std::string hash = params.at("hash");
    
    // Find transaction in all blocks
    bool found = false;
    Transaction tx;
    
    for (const auto& block : m_blockchain.getChain()) {
        for (const auto& transaction : block.getTransactions()) {
            // In a real implementation, transactions would have their own hash
            // For now, generate a simplified hash
            std::string txData = transaction.getFromAddress() + transaction.getToAddress() + 
                                std::to_string(transaction.getAmount()) + 
                                timePointToString(transaction.getTimestamp());
            std::string txHash = Utils::sha256(txData);
            
            if (txHash == hash) {
                tx = transaction;
                found = true;
                break;
            }
        }
        
        if (found) break;
    }
    
    if (!found) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = "Transaction with hash " + hash + " not found";
        return errorResponse;
    }
    
    // Build response
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["fromAddress"] = tx.getFromAddress();
    dataObj["toAddress"] = tx.getToAddress();
    dataObj["amount"] = tx.getAmount();
    dataObj["timestamp"] = timePointToString(tx.getTimestamp());
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleCreateTransaction(const std::string& body) {
    try {
        // Parse request body
        json requestJson = json::parse(body);
        
        // Extract transaction data
        std::string fromAddress = requestJson["fromAddress"];
        std::string toAddress = requestJson["toAddress"];
        double amount = requestJson["amount"];
        std::string signature = requestJson["signature"];
        
        // Create and add transaction
        Transaction tx(fromAddress, toAddress, amount);
        tx.setSignature(signature);
        
        // Check if transaction is valid
        bool isValid = m_blockchain.addTransaction(tx);
        
        if (!isValid) {
            json errorResponse;
            errorResponse["status"] = "error";
            errorResponse["message"] = "Invalid transaction";
            return errorResponse;
        }
        
        // Generate transaction hash
        std::string txData = tx.getFromAddress() + tx.getToAddress() + 
                           std::to_string(tx.getAmount()) + 
                           timePointToString(tx.getTimestamp());
        std::string txHash = Utils::sha256(txData);
        
        // Build response
        json response;
        response["status"] = "success";
        json dataObj;
        dataObj["hash"] = txHash;
        dataObj["message"] = "Transaction added to pending transactions";
        response["data"] = dataObj;
        
        return response;
    }
    catch (const std::exception& e) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = std::string("Error creating transaction: ") + e.what();
        return errorResponse;
    }
}

json APIServer::handleGetMempool() {
    const auto& pendingTransactions = m_blockchain.getPendingTransactions();
    
    // Build response
    json transactionsArray = json::array();
    
    for (const auto& tx : pendingTransactions) {
        // Generate transaction hash
        std::string txData = tx.getFromAddress() + tx.getToAddress() + 
                           std::to_string(tx.getAmount()) + 
                           timePointToString(tx.getTimestamp());
        std::string txHash = Utils::sha256(txData);
        
        json txJson;
        txJson["hash"] = txHash;
        txJson["fromAddress"] = tx.getFromAddress();
        txJson["toAddress"] = tx.getToAddress();
        txJson["amount"] = tx.getAmount();
        txJson["timestamp"] = timePointToString(tx.getTimestamp());
        
        transactionsArray.push_back(txJson);
    }
    
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["transactions"] = transactionsArray;
    dataObj["count"] = pendingTransactions.size();
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleGetBalance(const std::map<std::string, std::string>& params) {
    // Extract address
    if (params.find("address") == params.end()) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = "Address is required";
        return errorResponse;
    }
    
    std::string address = params.at("address");
    
    // Get balance
    double balance = m_blockchain.getBalanceOfAddress(address);
    
    // Build response
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["address"] = address;
    dataObj["balance"] = balance;
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleMineBlock(const std::string& body) {
    try {
        // Parse request body
        json requestJson = json::parse(body);
        
        // Extract mining address
        std::string miningRewardAddress = requestJson["rewardAddress"];
        
        // Mine a new block
        bool success = m_blockchain.minePendingTransactions(miningRewardAddress);
        
        if (!success) {
            json errorResponse;
            errorResponse["status"] = "error";
            errorResponse["message"] = "Failed to mine a new block";
            return errorResponse;
        }
        
        // Get the newly mined block
        const auto& chain = m_blockchain.getChain();
        const Block& newBlock = chain.back();
        
        // Build response
        json response;
        response["status"] = "success";
        json dataObj;
        dataObj["message"] = "New block mined successfully";
        dataObj["blockIndex"] = newBlock.getIndex();
        dataObj["blockHash"] = newBlock.getHash();
        dataObj["miningReward"] = m_blockchain.getMiningReward();
        dataObj["rewardAddress"] = miningRewardAddress;
        response["data"] = dataObj;
        
        return response;
    }
    catch (const std::exception& e) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = std::string("Error mining block: ") + e.what();
        return errorResponse;
    }
}

json APIServer::handleGetPeers() {
    // In a real implementation, this would return a list of connected peers
    // For now, return an empty array
    
    json response;
    response["status"] = "success";
    json dataObj;
    dataObj["peers"] = json::array();
    dataObj["count"] = 0;
    response["data"] = dataObj;
    
    return response;
}

json APIServer::handleAddPeer(const std::string& body) {
    try {
        // Parse request body
        json requestJson = json::parse(body);
        
        // Extract peer data
        std::string peerUrl = requestJson["url"];
        
        // In a real implementation, this would add a new peer to the network
        // For now, just return success
        
        json response;
        response["status"] = "success";
        json dataObj;
        dataObj["message"] = "Peer added successfully";
        dataObj["url"] = peerUrl;
        response["data"] = dataObj;
        
        return response;
    }
    catch (const std::exception& e) {
        json errorResponse;
        errorResponse["status"] = "error";
        errorResponse["message"] = std::string("Error adding peer: ") + e.what();
        return errorResponse;
    }
}