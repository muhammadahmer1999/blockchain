#include "../include/Storage.h"
#include "../src/block.h"
#include "../src/blockchain.h"
#include "../src/transaction.h"
#include "../src/utils.h"
#include <fstream>
#include <iostream>
#include <leveldb/write_batch.h>
#include <filesystem>
#include <thread>
#include <chrono>
#include <mutex>

// Define static constants for key prefixes
const std::string LevelDBStorage::BLOCK_PREFIX = "block:";
const std::string LevelDBStorage::BLOCK_HASH_PREFIX = "block_hash:";
const std::string LevelDBStorage::TX_PREFIX = "tx:";
const std::string LevelDBStorage::PENDING_TX_PREFIX = "pending_tx:";
const std::string LevelDBStorage::CONTRACT_PREFIX = "contract:";
const std::string LevelDBStorage::META_PREFIX = "meta:";

// Helper methods for key construction
std::string LevelDBStorage::blockKey(size_t index) const {
    return BLOCK_PREFIX + std::to_string(index);
}

std::string LevelDBStorage::blockHashKey(const std::string& hash) const {
    return BLOCK_HASH_PREFIX + hash;
}

std::string LevelDBStorage::txKey(const std::string& hash) const {
    return TX_PREFIX + hash;
}

std::string LevelDBStorage::pendingTxKey(const std::string& hash) const {
    return PENDING_TX_PREFIX + hash;
}

std::string LevelDBStorage::contractKey(const std::string& address) const {
    return CONTRACT_PREFIX + address;
}

std::string LevelDBStorage::metaKey(const std::string& key) const {
    return META_PREFIX + key;
}

// Constructor/Destructor
LevelDBStorage::LevelDBStorage() : db(nullptr) {}

LevelDBStorage::~LevelDBStorage() {
    close();
}

// Database operations
bool LevelDBStorage::open(const std::string& path) {
    std::lock_guard<std::mutex> lock(mutex);
    
    if (db) {
        return true; // Already open
    }
    
    dbPath = path;
    leveldb::Options options;
    options.create_if_missing = true;
    options.error_if_exists = false;
    
    // Create necessary directories
    try {
        std::filesystem::create_directories(path);
    } catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Failed to create directory: " << e.what() << std::endl;
    }
    
    // Try to fix possible resource issues by checking for lock file
    std::string lockFile = path + "/LOCK";
    if (std::filesystem::exists(lockFile)) {
        std::cout << "LevelDBStorage: Found stale lock file, attempting to remove..." << std::endl;
        try {
            std::filesystem::remove(lockFile);
        } catch (const std::exception& e) {
            std::cerr << "LevelDBStorage: Failed to remove lock file: " << e.what() << std::endl;
        }
    }
    
    // Try with recovery option first if database exists
    if (std::filesystem::exists(path)) {
        leveldb::Options recoveryOptions;
        recoveryOptions.create_if_missing = false;
        recoveryOptions.error_if_exists = false;
        recoveryOptions.paranoid_checks = true;
        
        // Try to recover database
        leveldb::DB* dbPtr = nullptr;
        leveldb::Status status = leveldb::RepairDB(path, recoveryOptions);
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Repair attempt failed: " << status.ToString() << std::endl;
        } else {
            std::cout << "LevelDBStorage: Database repair was successful" << std::endl;
        }
    }
    
    // Now attempt normal open
    int retries = 3;
    leveldb::Status status;
    leveldb::DB* dbPtr = nullptr;
    
    while (retries > 0) {
        status = leveldb::DB::Open(options, path, &dbPtr);
        if (status.ok()) {
            db.reset(dbPtr);
            break;
        } else {
            std::cerr << "LevelDBStorage: Failed to open database (attempt " 
                      << (4 - retries) << "/3): " << status.ToString() << std::endl;
            // Wait a bit before retrying
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            retries--;
        }
    }
    
    if (!status.ok()) {
        std::cerr << "LevelDBStorage: All attempts to open database failed: " << status.ToString() << std::endl;
        return false;
    }
    
    std::cout << "LevelDBStorage: Successfully opened database at " << path << std::endl;
    return true;
}

void LevelDBStorage::close() {
    std::lock_guard<std::mutex> lock(mutex);
    
    if (db) {
        db.reset();
    }
}

// Block operations
bool LevelDBStorage::saveBlock(const Block& block) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // Serialize block to JSON
        json blockJson;
        blockJson["index"] = block.getIndex();
        blockJson["timestamp"] = Utils::timePointToString(block.getTimestamp());
        blockJson["hash"] = block.getHash();
        blockJson["previousHash"] = block.getPreviousHash();
        blockJson["nonce"] = block.getNonce();
        
        // Add transactions
        json txsJson = json::array();
        for (const auto& tx : block.getTransactions()) {
            json txJson;
            txJson["fromAddress"] = tx.getFromAddress();
            txJson["toAddress"] = tx.getToAddress();
            txJson["amount"] = tx.getAmount();
            txJson["signature"] = tx.getSignature();
            txJson["timestamp"] = Utils::timePointToString(tx.getTimestamp());
            txsJson.push_back(txJson);
        }
        blockJson["transactions"] = txsJson;
        
        // Save block by index
        std::string blockData = blockJson.dump();
        leveldb::Status status = db->Put(leveldb::WriteOptions(), 
            blockKey(block.getIndex()), blockData);
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to save block: " << status.ToString() << std::endl;
            return false;
        }
        
        // Save block by hash for lookup
        status = db->Put(leveldb::WriteOptions(), 
            blockHashKey(block.getHash()), std::to_string(block.getIndex()));
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to save block hash: " << status.ToString() << std::endl;
            return false;
        }
        
        // Update block count
        size_t blockCount = getBlockCount();
        if (block.getIndex() >= blockCount) {
            status = db->Put(leveldb::WriteOptions(), 
                metaKey("block_count"), std::to_string(block.getIndex() + 1));
            
            if (!status.ok()) {
                std::cerr << "LevelDBStorage: Failed to update block count: " << status.ToString() << std::endl;
                return false;
            }
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in saveBlock: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::getBlock(size_t index, Block& block) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        std::string blockData;
        leveldb::Status status = db->Get(leveldb::ReadOptions(), 
            blockKey(index), &blockData);
        
        if (!status.ok()) {
            return false;
        }
        
        // Deserialize block from JSON
        json blockJson = json::parse(blockData);
        
        // Create transactions
        std::vector<Transaction> transactions;
        for (const auto& txJson : blockJson["transactions"]) {
            Transaction tx(
                txJson["fromAddress"],
                txJson["toAddress"],
                txJson["amount"]
            );
            // Set additional fields
            if (txJson.contains("signature")) {
                // Set signature (this is a simplified approach)
                tx.setSignature(txJson["signature"]);
            }
            transactions.push_back(tx);
        }
        
        // Create block with the data
        // First create an empty block
        block = Block();
        // Then set its properties
        block.setIndex(blockJson["index"]);
        block.setPreviousHash(blockJson["previousHash"]);
        block.setTransactions(transactions);
        
        // Set additional fields that might be computed when mining
        block.setHash(blockJson["hash"]);
        block.setNonce(blockJson["nonce"]);
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in getBlock: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::getBlockByHash(const std::string& hash, Block& block) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // Get block index from hash
        std::string indexStr;
        leveldb::Status status = db->Get(leveldb::ReadOptions(), 
            blockHashKey(hash), &indexStr);
        
        if (!status.ok()) {
            return false;
        }
        
        // Now get the actual block
        size_t index = std::stoull(indexStr);
        return getBlock(index, block);
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in getBlockByHash: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::deleteBlock(size_t index) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // First, get the block to retrieve its hash
        Block block;
        if (!getBlock(index, block)) {
            return false;
        }
        
        // Delete block hash mapping
        leveldb::Status status = db->Delete(leveldb::WriteOptions(), 
            blockHashKey(block.getHash()));
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to delete block hash: " << status.ToString() << std::endl;
            return false;
        }
        
        // Delete block data
        status = db->Delete(leveldb::WriteOptions(), blockKey(index));
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to delete block: " << status.ToString() << std::endl;
            return false;
        }
        
        // Update block count if necessary
        size_t blockCount = getBlockCount();
        if (index == blockCount - 1) {
            status = db->Put(leveldb::WriteOptions(), 
                metaKey("block_count"), std::to_string(blockCount - 1));
            
            if (!status.ok()) {
                std::cerr << "LevelDBStorage: Failed to update block count: " << status.ToString() << std::endl;
                return false;
            }
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in deleteBlock: " << e.what() << std::endl;
        return false;
    }
}

size_t LevelDBStorage::getBlockCount() {
    if (!db) return 0;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        std::string countStr;
        leveldb::Status status = db->Get(leveldb::ReadOptions(), 
            metaKey("block_count"), &countStr);
        
        if (!status.ok()) {
            return 0;
        }
        
        return std::stoull(countStr);
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in getBlockCount: " << e.what() << std::endl;
        return 0;
    }
}

// Transaction operations
bool LevelDBStorage::saveTransaction(const Transaction& transaction) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // Generate a transaction hash (in a real implementation, this would be part of the Transaction class)
        std::string hash = transaction.getFromAddress() + transaction.getToAddress() + 
                          std::to_string(transaction.getAmount()) + Utils::timePointToString(transaction.getTimestamp());
        hash = Utils::sha256(hash);
        
        // Serialize transaction to JSON
        json txJson;
        txJson["fromAddress"] = transaction.getFromAddress();
        txJson["toAddress"] = transaction.getToAddress();
        txJson["amount"] = transaction.getAmount();
        txJson["signature"] = transaction.getSignature();
        txJson["timestamp"] = Utils::timePointToString(transaction.getTimestamp());
        
        std::string txData = txJson.dump();
        leveldb::Status status = db->Put(leveldb::WriteOptions(), 
            txKey(hash), txData);
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to save transaction: " << status.ToString() << std::endl;
            return false;
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in saveTransaction: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::getTransaction(const std::string& hash, Transaction& transaction) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        std::string txData;
        leveldb::Status status = db->Get(leveldb::ReadOptions(), 
            txKey(hash), &txData);
        
        if (!status.ok()) {
            return false;
        }
        
        // Deserialize transaction from JSON
        json txJson = json::parse(txData);
        
        transaction = Transaction(
            txJson["fromAddress"],
            txJson["toAddress"],
            txJson["amount"]
        );
        
        // Set signature if available
        if (txJson.contains("signature")) {
            transaction.setSignature(txJson["signature"]);
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in getTransaction: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::savePendingTransaction(const Transaction& transaction) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // Generate a transaction hash
        std::string hash = transaction.getFromAddress() + transaction.getToAddress() + 
                          std::to_string(transaction.getAmount()) + Utils::timePointToString(transaction.getTimestamp());
        hash = Utils::sha256(hash);
        
        // Serialize transaction to JSON
        json txJson;
        txJson["fromAddress"] = transaction.getFromAddress();
        txJson["toAddress"] = transaction.getToAddress();
        txJson["amount"] = transaction.getAmount();
        txJson["signature"] = transaction.getSignature();
        txJson["timestamp"] = Utils::timePointToString(transaction.getTimestamp());
        
        std::string txData = txJson.dump();
        leveldb::Status status = db->Put(leveldb::WriteOptions(), 
            pendingTxKey(hash), txData);
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to save pending transaction: " << status.ToString() << std::endl;
            return false;
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in savePendingTransaction: " << e.what() << std::endl;
        return false;
    }
}

std::vector<Transaction> LevelDBStorage::getPendingTransactions(size_t limit) {
    std::vector<Transaction> transactions;
    
    if (!db) return transactions;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        size_t count = 0;
        
        // Iterate over all pending transactions
        std::unique_ptr<leveldb::Iterator> it(db->NewIterator(leveldb::ReadOptions()));
        for (it->Seek(PENDING_TX_PREFIX); 
             it->Valid() && 
             it->key().ToString().substr(0, PENDING_TX_PREFIX.size()) == PENDING_TX_PREFIX && 
             count < limit; 
             it->Next(), count++) {
            
            try {
                // Parse transaction data
                json txJson = json::parse(it->value().ToString());
                
                Transaction tx(
                    txJson["fromAddress"],
                    txJson["toAddress"],
                    txJson["amount"]
                );
                
                // Set signature if available
                if (txJson.contains("signature")) {
                    tx.setSignature(txJson["signature"]);
                }
                
                transactions.push_back(tx);
            }
            catch (const std::exception& e) {
                std::cerr << "LevelDBStorage: Exception parsing pending transaction: " << e.what() << std::endl;
                continue;
            }
        }
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in getPendingTransactions: " << e.what() << std::endl;
    }
    
    return transactions;
}

// Smart contract operations are placeholders until we implement SmartContract
bool LevelDBStorage::saveSmartContract(const std::shared_ptr<SmartContract>&) {
    // Placeholder implementation
    return false;
}

std::shared_ptr<SmartContract> LevelDBStorage::getSmartContract(const std::string&) {
    // Placeholder implementation
    return nullptr;
}

// Chain state operations
bool LevelDBStorage::saveChainState(const Blockchain& blockchain) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        // Serialize basic blockchain state
        json stateJson;
        stateJson["difficulty"] = blockchain.getDifficulty();
        stateJson["miningReward"] = blockchain.getMiningReward();
        
        std::string stateData = stateJson.dump();
        leveldb::Status status = db->Put(leveldb::WriteOptions(), 
            metaKey("chain_state"), stateData);
        
        if (!status.ok()) {
            std::cerr << "LevelDBStorage: Failed to save chain state: " << status.ToString() << std::endl;
            return false;
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in saveChainState: " << e.what() << std::endl;
        return false;
    }
}

bool LevelDBStorage::loadChainState(Blockchain& blockchain) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    try {
        std::string stateData;
        leveldb::Status status = db->Get(leveldb::ReadOptions(), 
            metaKey("chain_state"), &stateData);
        
        if (!status.ok()) {
            return false;
        }
        
        // Deserialize blockchain state
        json stateJson = json::parse(stateData);
        
        if (stateJson.contains("difficulty")) {
            blockchain.setDifficulty(stateJson["difficulty"]);
        }
        
        if (stateJson.contains("miningReward")) {
            blockchain.setMiningReward(stateJson["miningReward"]);
        }
        
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "LevelDBStorage: Exception in loadChainState: " << e.what() << std::endl;
        return false;
    }
}

// General key-value operations
bool LevelDBStorage::put(const std::string& key, const std::string& value) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    leveldb::Status status = db->Put(leveldb::WriteOptions(), key, value);
    return status.ok();
}

bool LevelDBStorage::get(const std::string& key, std::string& value) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    leveldb::Status status = db->Get(leveldb::ReadOptions(), key, &value);
    return status.ok();
}

bool LevelDBStorage::remove(const std::string& key) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    leveldb::Status status = db->Delete(leveldb::WriteOptions(), key);
    return status.ok();
}

// LevelDB batch operations
bool LevelDBStorage::batch(const std::vector<std::pair<std::string, std::string>>& operations) {
    if (!db) return false;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    leveldb::WriteBatch batch;
    
    for (const auto& op : operations) {
        if (op.second.empty()) {
            batch.Delete(op.first);
        } else {
            batch.Put(op.first, op.second);
        }
    }
    
    leveldb::Status status = db->Write(leveldb::WriteOptions(), &batch);
    return status.ok();
}

// Iterator for bulk operations
void LevelDBStorage::iterate(const std::string& prefix, 
                           std::function<bool(const std::string&, const std::string&)> callback) {
    if (!db) return;
    
    std::lock_guard<std::mutex> lock(mutex);
    
    std::unique_ptr<leveldb::Iterator> it(db->NewIterator(leveldb::ReadOptions()));
    for (it->Seek(prefix); 
         it->Valid() && 
         it->key().ToString().substr(0, prefix.size()) == prefix; 
         it->Next()) {
        
        std::string key = it->key().ToString();
        std::string value = it->value().ToString();
        
        if (!callback(key, value)) {
            break;
        }
    }
}