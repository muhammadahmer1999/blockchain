/**
 * @file block.h
 * @brief Definition of the Block class
 */

#pragma once

#include "transaction.h"
#include <string>
#include <vector>
#include <chrono>
#include <cstdint>

/**
 * @class Block
 * @brief Represents a block in the blockchain
 */
class Block {
public:
    /**
     * @brief Default constructor
     */
    Block();

    /**
     * @brief Constructor for a new Block
     * @param index The position of the block in the chain
     * @param timestamp When the block was created
     * @param transactions The transactions included in the block
     * @param previousHash The hash of the previous block
     */
    Block(uint32_t index, 
          std::chrono::system_clock::time_point timestamp, 
          const std::vector<Transaction>& transactions, 
          const std::string& previousHash);

    /**
     * @brief Calculate the hash of the block
     * @return The SHA256 hash of the block
     */
    std::string calculateHash() const;

    /**
     * @brief Mine the block with a specific difficulty
     * @param difficulty The number of leading zeros required in the hash
     */
    void mineBlock(uint32_t difficulty);

    /**
     * @brief Get the index of the block
     * @return The block index
     */
    uint32_t getIndex() const;

    /**
     * @brief Get the timestamp of the block
     * @return The block timestamp
     */
    std::chrono::system_clock::time_point getTimestamp() const;

    /**
     * @brief Get the nonce value used for mining
     * @return The nonce value
     */
    uint64_t getNonce() const;

    /**
     * @brief Get the hash of the block
     * @return The block hash
     */
    const std::string& getHash() const;

    /**
     * @brief Get the previous block's hash
     * @return The previous block hash
     */
    const std::string& getPreviousHash() const;

    /**
     * @brief Get all transactions in the block
     * @return Vector of transactions
     */
    const std::vector<Transaction>& getTransactions() const;

    /**
     * @brief Set the index of the block
     * @param index The new index value
     */
    void setIndex(uint32_t index);

    /**
     * @brief Set the hash of the block
     * @param hash The new hash value
     */
    void setHash(const std::string& hash);

    /**
     * @brief Set the previous hash value
     * @param prevHash The new previous hash value
     */
    void setPreviousHash(const std::string& prevHash);

    /**
     * @brief Set the nonce value of the block
     * @param nonce The new nonce value
     */
    void setNonce(uint64_t nonce);

    /**
     * @brief Set the transactions in the block
     * @param transactions The new vector of transactions
     */
    void setTransactions(const std::vector<Transaction>& transactions);

    /**
     * @brief Convert block to JSON string
     * @return JSON representation of the block
     */
    std::string toJson() const;

private:
    uint32_t m_index;
    std::chrono::system_clock::time_point m_timestamp;
    std::vector<Transaction> m_transactions;
    std::string m_previousHash;
    std::string m_hash;
    uint64_t m_nonce;
};
