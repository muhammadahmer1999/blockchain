/**
 * @file cli.h
 * @brief Definition of the CLI class for user interaction
 */

#pragma once

#include "blockchain.h"
#include "wallet.h"
#include "../include/MemoryStorage.h"
#include <string>
#include <memory>
#include <functional>
#include <map>
#include <vector>
#include <fstream>

/**
 * @class CLI
 * @brief Command-line interface for interacting with the blockchain
 */
class CLI {
public:
    /**
     * @brief Constructor
     * @param blockchain Reference to the blockchain
     */
    explicit CLI(Blockchain& blockchain);

    /**
     * @brief Run the CLI main loop
     */
    void run();

private:
    Blockchain& m_blockchain;
    std::unique_ptr<Wallet> m_wallet;
    std::unique_ptr<MemoryStorage> m_memoryStorage;
    bool m_running;
    
    std::map<std::string, std::function<void()>> m_commands;
    
    // Memory reward settings
    const double MEMORY_UPLOAD_REWARD = 10.0; // 10 coins per unique memory

    /**
     * @brief Initialize the available commands
     */
    void initCommands();

    /**
     * @brief Print the main menu
     */
    void printMenu() const;

    /**
     * @brief Create a new wallet
     */
    void createWallet();

    /**
     * @brief Display the current wallet address
     */
    void showWalletAddress();

    /**
     * @brief Show the wallet balance
     */
    void showWalletBalance();

    /**
     * @brief Create a new transaction
     */
    void createTransaction();

    /**
     * @brief Mine pending transactions
     */
    void mineBlock();

    /**
     * @brief Show the blockchain
     */
    void showBlockchain();

    /**
     * @brief Show pending transactions
     */
    void showPendingTransactions();

    /**
     * @brief Validate the blockchain
     */
    void validateBlockchain();

    /**
     * @brief Adjust the mining difficulty
     */
    void adjustDifficulty();
    
    /**
     * @brief Upload a memory to the blockchain
     */
    void uploadMemory();
    
    /**
     * @brief View memories owned by the current wallet
     */
    void viewMyMemories();
    
    /**
     * @brief View public memories
     */
    void viewPublicMemories();
    
    /**
     * @brief Read file into binary data
     * @param filePath Path to the file
     * @return File contents as string
     */
    std::string readFileToString(const std::string& filePath);
    
    /**
     * @brief Calculate hash of a memory content
     * @param content Memory content
     * @return Hash as string
     */
    std::string calculateMemoryHash(const std::string& content);
    
    /**
     * @brief Process reward for unique memory upload
     * @param memoryHash Hash of the uploaded memory
     * @return True if reward was processed
     */
    bool processMemoryReward(const std::string& memoryHash);
    
    /**
     * @brief Save file to disk from memory
     * @param content File content
     * @param filename Filename to save as
     * @return True if successful
     */
    bool saveFileToDisk(const std::string& content, const std::string& filename);

    /**
     * @brief Exit the CLI
     */
    void exit();
};
