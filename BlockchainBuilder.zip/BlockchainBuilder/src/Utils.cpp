#include "../include/Utils.h"
#include <cryptopp/filters.h>
#include <cryptopp/base64.h>

std::string Utils::sha256(const std::string& input) {
    CryptoPP::SHA256 hash;
    std::string digest;
    
    CryptoPP::StringSource ss(input, true,
        new CryptoPP::HashFilter(hash,
            new CryptoPP::HexEncoder(
                new CryptoPP::StringSink(digest)
            )
        )
    );
    
    return digest;
}

std::string Utils::bytesToHexString(const std::vector<unsigned char>& bytes) {
    std::stringstream ss;
    
    for (const auto& byte : bytes) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    
    return ss.str();
}

std::vector<unsigned char> Utils::hexStringToBytes(const std::string& hex) {
    std::vector<unsigned char> bytes;
    
    for (size_t i = 0; i < hex.length(); i += 2) {
        std::string byteString = hex.substr(i, 2);
        unsigned char byte = static_cast<unsigned char>(std::stoi(byteString, nullptr, 16));
        bytes.push_back(byte);
    }
    
    return bytes;
}

std::string Utils::base64Decode(const std::string& input) {
    std::string decoded;
    
    CryptoPP::StringSource ss(input, true,
        new CryptoPP::Base64Decoder(
            new CryptoPP::StringSink(decoded)
        )
    );
    
    return decoded;
}

std::string Utils::base64Encode(const std::string& input) {
    std::string encoded;
    
    CryptoPP::StringSource ss(input, true,
        new CryptoPP::Base64Encoder(
            new CryptoPP::StringSink(encoded),
            false  // No line breaks
        )
    );
    
    return encoded;
}
