/**
 * @file utils.cpp
 * @brief Implementation of utility functions
 */

#include "utils.h"
#include <cryptopp/sha.h>
#include <cryptopp/hex.h>
#include <cryptopp/eccrypto.h>
#include <cryptopp/osrng.h>
#include <cryptopp/oids.h>
#include <iomanip>
#include <sstream>
#include <ctime>

using namespace CryptoPP;

namespace Utils {

std::string sha256(const std::string& input) {
    SHA256 hash;
    std::string digest;
    
    StringSource ss(input, true,
        new HashFilter(hash,
            new HexEncoder(
                new StringSink(digest)
            )
        )
    );
    
    return digest;
}

std::string timePointToString(const std::chrono::system_clock::time_point& time) {
    auto timeT = std::chrono::system_clock::to_time_t(time);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&timeT), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

// A simplified signing function - in a real implementation, use proper ECDSA
std::string signMessage(const std::string& message, const std::vector<uint8_t>& privateKey) {
    // In a real implementation, we would:
    // 1. Hash the message
    // 2. Sign the hash with the private key
    // 3. Return the signature
    
    // For simplicity in this example, we'll just concatenate the private key hash with the message hash
    // This is NOT secure and is only for demonstration purposes
    try {
        std::string privateKeyStr(privateKey.begin(), privateKey.end());
        std::string combined = message + privateKeyStr;
        return sha256(combined);
    } catch (const Exception& e) {
        throw std::runtime_error(std::string("Signing error: ") + e.what());
    }
}

// A simplified verification function - in a real implementation, use proper ECDSA
bool verifySignature(const std::string& message, const std::string& signature, const std::vector<uint8_t>& publicKey) {
    // In a real implementation, we would:
    // 1. Hash the message
    // 2. Verify the signature against the hash using the public key
    // 3. Return the verification result
    
    // For this simplified example, we return true if the signature is not empty
    // This is NOT secure and is only for demonstration purposes
    return !signature.empty();
}

std::string base64Encode(const std::string& data) {
    // Simple base64 encoding implementation
    static const std::string base64_chars = 
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";
    
    std::string encoded;
    int i = 0;
    int j = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];
    
    for (size_t idx = 0; idx < data.size(); ++idx) {
        char_array_3[i++] = data[idx];
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;
            
            for (i = 0; i < 4; i++)
                encoded += base64_chars[char_array_4[i]];
            i = 0;
        }
    }
    
    if (i) {
        for (j = i; j < 3; j++)
            char_array_3[j] = '\0';
        
        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
        
        for (j = 0; j < i + 1; j++)
            encoded += base64_chars[char_array_4[j]];
        
        while (i++ < 3)
            encoded += '=';
    }
    
    return encoded;
}

std::string base64Decode(const std::string& encoded) {
    // Simple base64 decoding implementation
    static const std::string base64_chars = 
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";
    
    std::string data;
    int i = 0;
    int j = 0;
    int in_ = 0;
    unsigned char char_array_4[4], char_array_3[3];
    
    for (size_t idx = 0; idx < encoded.size(); ++idx) {
        if (encoded[idx] == '=') break;
        
        if (encoded[idx] != '\n' && encoded[idx] != '\r') {
            size_t pos = base64_chars.find(encoded[idx]);
            if (pos == std::string::npos) break; // Invalid character
            
            char_array_4[i++] = pos;
            if (i == 4) {
                char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
                char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
                char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];
                
                for (i = 0; i < 3; i++)
                    data += char_array_3[i];
                i = 0;
            }
        }
    }
    
    if (i) {
        for (j = 0; j < i; j++)
            char_array_4[j] = base64_chars.find(char_array_4[j]);
        
        char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
        char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
        
        for (j = 0; j < i - 1; j++)
            data += char_array_3[j];
    }
    
    return data;
}

bool startsWith(const std::string& str, const std::string& prefix) {
    if (str.length() < prefix.length())
        return false;
    return str.substr(0, prefix.length()) == prefix;
}

} // namespace Utils
