/**
 * @file utils.h
 * @brief Utility functions for the blockchain
 */

#pragma once

#include <string>
#include <vector>
#include <chrono>

/**
 * @namespace Utils
 * @brief Contains utility functions for the blockchain
 */
namespace Utils {
    /**
     * @brief Calculate SHA256 hash of a string
     * @param input The input string
     * @return The hex-encoded SHA256 hash
     */
    std::string sha256(const std::string& input);
    
    /**
     * @brief Convert a time point to a string
     * @param time The time point to convert
     * @return Formatted string representation
     */
    std::string timePointToString(const std::chrono::system_clock::time_point& time);
    
    /**
     * @brief Sign a message with a private key
     * @param message The message to sign
     * @param privateKey The private key to use
     * @return The signature
     */
    std::string signMessage(const std::string& message, const std::vector<uint8_t>& privateKey);
    
    /**
     * @brief Verify a signature
     * @param message The original message
     * @param signature The signature to verify
     * @param publicKey The public key to use for verification
     * @return true if signature is valid
     */
    bool verifySignature(const std::string& message, const std::string& signature, const std::vector<uint8_t>& publicKey);
    
    /**
     * @brief Encode binary data to base64
     * @param data The data to encode
     * @return Base64 encoded string
     */
    std::string base64Encode(const std::string& data);
    
    /**
     * @brief Decode base64 data to binary
     * @param encoded The base64 encoded data
     * @return Decoded binary data
     */
    std::string base64Decode(const std::string& encoded);
    
    /**
     * @brief Check if a string starts with a prefix (C++17 compatibility)
     * @param str The string to check
     * @param prefix The prefix to check for
     * @return true if str starts with prefix
     */
    bool startsWith(const std::string& str, const std::string& prefix);
}
