/**
 * @file blockchain.h
 * @brief Definition of the Blockchain class
 */

#pragma once

#include "block.h"
#include "transaction.h"
#include <vector>
#include <unordered_map>
#include <memory>
#include <mutex>

/**
 * @class Blockchain
 * @brief Represents the main blockchain data structure and operations
 */
class Blockchain {
public:
    /**
     * @brief Constructor to initialize a new blockchain
     * @param difficulty Initial mining difficulty
     * @param miningReward Reward for mining a block
     * @param isMainnet Flag indicating if running in mainnet mode
     * @param networkId Network identifier string
     */
    Blockchain(int difficulty = 4, double miningReward = 50.0, bool isMainnet = false, const std::string& networkId = "testnet");

    /**
     * @brief Add a new transaction to the pending transactions
     * @param transaction The transaction to add
     * @return true if transaction was added successfully
     */
    bool addTransaction(const Transaction& transaction);

    /**
     * @brief Get the last block in the chain
     * @return Reference to the last block
     */
    const Block& getLatestBlock() const;

    /**
     * @brief Mine pending transactions and add a new block to the chain
     * @param minerAddress Address to receive mining reward
     * @return true if mining was successful
     */
    bool minePendingTransactions(const std::string& minerAddress);

    /**
     * @brief Check if the blockchain is valid
     * @return true if the chain is valid
     */
    bool isChainValid() const;

    /**
     * @brief Get the balance for a specific address
     * @param address The address to check
     * @return The balance amount
     */
    double getBalanceOfAddress(const std::string& address) const;

    /**
     * @brief Get all blocks in the blockchain
     * @return Vector of all blocks
     */
    const std::vector<Block>& getChain() const;

    /**
     * @brief Get all pending transactions
     * @return Vector of pending transactions
     */
    const std::vector<Transaction>& getPendingTransactions() const;

    /**
     * @brief Adjust the mining difficulty
     * @param newDifficulty New difficulty level
     */
    void setDifficulty(uint32_t newDifficulty);

    /**
     * @brief Get the current mining difficulty
     * @return Current difficulty level
     */
    uint32_t getDifficulty() const;

    /**
     * @brief Get the mining reward amount
     * @return Current mining reward
     */
    double getMiningReward() const;

    /**
     * @brief Set the mining reward
     * @param reward New mining reward amount
     */
    void setMiningReward(double reward);
    
    /**
     * @brief Check if blockchain is running in mainnet mode
     * @return true if running in mainnet mode
     */
    bool isMainnet() const;
    
    /**
     * @brief Get the network identifier
     * @return Network ID string
     */
    std::string getNetworkId() const;

private:
    std::vector<Block> m_chain;
    std::vector<Transaction> m_pendingTransactions;
    uint32_t m_difficulty;
    double m_miningReward;
    bool m_isMainnet;
    std::string m_networkId;
    mutable std::mutex m_chainMutex;
    mutable std::mutex m_pendingTransactionsMutex;

    /**
     * @brief Create the genesis block
     * @return The genesis block
     */
    Block createGenesisBlock() const;
};
