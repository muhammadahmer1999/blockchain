#include "../include/Blockchain.h"
#include <stdexcept>
#include <iostream>

Blockchain::Blockchain(unsigned int difficulty, double miningReward, bool isMainnet, const std::string& networkId) {
    this->difficulty = difficulty;
    this->miningReward = miningReward;
    this->storage = nullptr; // Initialize storage to nullptr
    this->isMainnet = isMainnet;
    this->networkId = networkId;
    
    // Set mainnet parameters
    if (isMainnet) {
        this->maxBlockSize = 1048576;  // 1MB (1024*1024)
        this->maxTransactionsPerBlock = 2000;
        this->blockTime = 600;  // 10 minutes target time
        this->halvingInterval = 210000;  // Similar to Bitcoin
    } else {
        // Testnet parameters - more relaxed for development
        this->maxBlockSize = 2097152;  // 2MB
        this->maxTransactionsPerBlock = 5000;
        this->blockTime = 300;  // 5 minutes target time
        this->halvingInterval = 21000;  // Shorter for testing
    }
    
    createGenesisBlock();
}

void Blockchain::createGenesisBlock() {
    std::vector<Transaction> genesisTransactions;
    // For genesis block, we can create an empty transaction or a special one
    Transaction genesisTx("", "Genesis", 0);
    genesisTransactions.push_back(genesisTx);
    
    chain.push_back(Block(0, "0", genesisTransactions));
}

const Block& Blockchain::getLatestBlock() const {
    return chain.back();
}

void Blockchain::minePendingTransactions(const std::string& miningRewardAddress) {
    // In real blockchain, miners get to choose transactions they include
    // Here we simply take all pending transactions
    
    // First create a reward transaction
    Transaction rewardTx("", miningRewardAddress, miningReward);
    pendingTransactions.push_back(rewardTx);
    
    // Create a new block with all pending transactions
    Block newBlock(chain.size(), getLatestBlock().getHash(), pendingTransactions);
    newBlock.mineBlock(difficulty);
    
    std::cout << "Block successfully mined!" << std::endl;
    chain.push_back(newBlock);
    
    // Clear the pending transactions but create a new reward for the next mining round
    pendingTransactions.clear();
}

bool Blockchain::addTransaction(const Transaction& transaction) {
    // Check if transaction is valid
    if (transaction.getFromAddress().empty() && transaction.getToAddress().empty()) {
        return false;
    }
    
    if (!transaction.isValid()) {
        return false;
    }
    
    // Check if sender has enough balance
    if (transaction.getFromAddress() != "") {  // Skip for mining rewards
        double senderBalance = getBalanceOfAddress(transaction.getFromAddress());
        if (senderBalance < transaction.getAmount()) {
            std::cout << "Not enough balance!" << std::endl;
            return false;
        }
    }
    
    pendingTransactions.push_back(transaction);
    return true;
}

double Blockchain::getBalanceOfAddress(const std::string& address) const {
    double balance = 0;
    
    for (const auto& block : chain) {
        for (const auto& trans : block.getTransactions()) {
            // If this address is the sender, reduce the balance
            if (trans.getFromAddress() == address) {
                balance -= trans.getAmount();
            }
            
            // If this address is the recipient, increase the balance
            if (trans.getToAddress() == address) {
                balance += trans.getAmount();
            }
        }
    }
    
    return balance;
}

bool Blockchain::isChainValid() const {
    // Check if genesis block is valid
    if (chain.size() < 1) {
        return false;
    }
    
    // Check each block
    for (size_t i = 1; i < chain.size(); i++) {
        const Block& currentBlock = chain[i];
        const Block& previousBlock = chain[i - 1];
        
        // Check if hash is correctly calculated
        if (currentBlock.calculateHash() != currentBlock.getHash()) {
            return false;
        }
        
        // Check if points to correct previous block
        if (currentBlock.getPreviousHash() != previousBlock.getHash()) {
            return false;
        }
        
        // Check if all transactions are valid
        if (!currentBlock.hasValidTransactions()) {
            return false;
        }
    }
    
    return true;
}

json Blockchain::toJson() const {
    json j;
    
    json chainJson = json::array();
    for (const auto& block : chain) {
        chainJson.push_back(block.toJson());
    }
    j["chain"] = chainJson;
    
    json pendingJson = json::array();
    for (const auto& tx : pendingTransactions) {
        pendingJson.push_back(tx.toJson());
    }
    j["pendingTransactions"] = pendingJson;
    
    j["difficulty"] = difficulty;
    j["miningReward"] = miningReward;
    j["isMainnet"] = isMainnet;
    j["networkId"] = networkId;
    j["maxBlockSize"] = maxBlockSize;
    j["maxTransactionsPerBlock"] = maxTransactionsPerBlock;
    j["blockTime"] = blockTime;
    j["halvingInterval"] = halvingInterval;
    
    return j;
}

Blockchain Blockchain::fromJson(const json& j) {
    // Create blockchain with basic parameters
    bool isMainnet = j.contains("isMainnet") ? j["isMainnet"].get<bool>() : false;
    std::string networkId = j.contains("networkId") ? j["networkId"].get<std::string>() : "testnet";
    
    Blockchain blockchain(
        j["difficulty"].get<unsigned int>(), 
        j["miningReward"].get<double>(),
        isMainnet,
        networkId
    );
    
    // Clear the default genesis block
    blockchain.chain.clear();
    
    // Load the chain
    for (const auto& blockJson : j["chain"]) {
        blockchain.chain.push_back(Block::fromJson(blockJson));
    }
    
    // Load pending transactions
    for (const auto& txJson : j["pendingTransactions"]) {
        blockchain.pendingTransactions.push_back(Transaction::fromJson(txJson));
    }
    
    return blockchain;
}
