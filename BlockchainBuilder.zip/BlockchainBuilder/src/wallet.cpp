/**
 * @file wallet.cpp
 * @brief Implementation of the Wallet class
 */

#include "wallet.h"
#include "utils.h"
#include <cryptopp/osrng.h>
#include <cryptopp/eccrypto.h>
#include <cryptopp/oids.h>
#include <cryptopp/hex.h>
#include <iostream>

using namespace CryptoPP;

Wallet::Wallet() {
    generateKeypair();
}

void Wallet::generateKeypair() {
    try {
        // Generate a random private key
        AutoSeededRandomPool prng;
        
        // Generate a private key using secp256k1 curve (commonly used in blockchains)
        ECDSA<ECP, SHA256>::PrivateKey privateKey;
        privateKey.Initialize(prng, ASN1::secp256k1());
        
        // Extract the private key bytes
        size_t privateKeySize = privateKey.GetPrivateExponent().ByteCount();
        m_privateKey.resize(privateKeySize);
        privateKey.GetPrivateExponent().Encode(m_privateKey.data(), privateKeySize);
        
        // Generate corresponding public key
        ECDSA<ECP, SHA256>::PublicKey publicKey;
        privateKey.MakePublicKey(publicKey);
        
        // Validate the key pair
        if (!privateKey.Validate(prng, 3) || !publicKey.Validate(prng, 3)) {
            throw std::runtime_error("Failed to validate keypair");
        }
        
        // Extract the public key point
        const ECPPoint& pubElement = publicKey.GetPublicElement();
        
        // Get coordinates
        const Integer& x = pubElement.x;
        const Integer& y = pubElement.y;
        
        // Calculate space needed
        size_t xSize = x.ByteCount();
        size_t ySize = y.ByteCount();
        size_t publicKeySize = xSize + ySize + 1; // +1 for the uncompressed point marker
        
        // Resize buffer
        m_publicKey.resize(publicKeySize);
        
        // Set uncompressed point marker
        m_publicKey[0] = 0x04;
        
        // Encode X coordinate
        x.Encode(m_publicKey.data() + 1, xSize);
        
        // Encode Y coordinate
        y.Encode(m_publicKey.data() + 1 + xSize, ySize);
        
        // Generate address from public key (simplified - just use a hash of the public key)
        m_publicAddress = Utils::sha256(std::string(m_publicKey.begin(), m_publicKey.end()));
        
        // Format like cryptocurrency addresses - just take first 40 chars and add prefix
        m_publicAddress = "0x" + m_publicAddress.substr(0, 40);
        
    } catch (const Exception& e) {
        std::cerr << "Crypto++ Exception: " << e.what() << std::endl;
        throw;
    }
}

std::string Wallet::getPublicAddress() const {
    return m_publicAddress;
}

std::string Wallet::sign(const std::string& dataToSign) const {
    try {
        // This is a simplified signing implementation
        // In a real-world scenario, we would use proper ECDSA signatures
        // For demo purposes, we'll use a simplified approach
        return Utils::signMessage(dataToSign, m_privateKey);
    } catch (const Exception& e) {
        std::cerr << "Crypto++ Exception during signing: " << e.what() << std::endl;
        throw;
    }
}

const std::vector<uint8_t>& Wallet::getPrivateKey() const {
    return m_privateKey;
}
