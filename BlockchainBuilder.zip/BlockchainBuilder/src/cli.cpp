/**
 * @file cli.cpp
 * @brief Implementation of the CLI class
 */

#include "cli.h"
#include <iostream>
#include <string>
#include <limits>
#include <iomanip>
#include <algorithm>
#include <filesystem>
#include "utils.h"

CLI::CLI(Blockchain& blockchain)
    : m_blockchain(blockchain), m_wallet(nullptr), m_memoryStorage(nullptr), m_running(false) {
    
    // Initialize memory storage
    m_memoryStorage = std::make_unique<MemoryStorage>("./data/memories");
    
    // Initialize commands
    initCommands();
}

void CLI::initCommands() {
    m_commands["1"] = [this]() { createWallet(); };
    m_commands["2"] = [this]() { showWalletAddress(); };
    m_commands["3"] = [this]() { showWalletBalance(); };
    m_commands["4"] = [this]() { createTransaction(); };
    m_commands["5"] = [this]() { mineBlock(); };
    m_commands["6"] = [this]() { showBlockchain(); };
    m_commands["7"] = [this]() { showPendingTransactions(); };
    m_commands["8"] = [this]() { validateBlockchain(); };
    m_commands["9"] = [this]() { adjustDifficulty(); };
    m_commands["10"] = [this]() { uploadMemory(); };
    m_commands["11"] = [this]() { viewMyMemories(); };
    m_commands["12"] = [this]() { viewPublicMemories(); };
    m_commands["0"] = [this]() { exit(); };
}

void CLI::run() {
    m_running = true;
    
    std::cout << "\n===== Ahmiyat Blockchain =====\n" << std::endl;
    
    while (m_running) {
        printMenu();
        
        std::string choice;
        std::cout << "Enter choice: ";
        std::getline(std::cin, choice);
        
        auto it = m_commands.find(choice);
        if (it != m_commands.end()) {
            it->second();
        } else {
            std::cout << "Invalid option. Please try again." << std::endl;
        }
    }
}

void CLI::printMenu() const {
    std::cout << "\n===== MENU =====\n";
    std::cout << "1. Create Wallet\n";
    std::cout << "2. Show Wallet Address\n";
    std::cout << "3. Show Wallet Balance\n";
    std::cout << "4. Create Transaction\n";
    std::cout << "5. Mine Block\n";
    std::cout << "6. Show Blockchain\n";
    std::cout << "7. Show Pending Transactions\n";
    std::cout << "8. Validate Blockchain\n";
    std::cout << "9. Adjust Mining Difficulty\n";
    std::cout << "10. Upload Memory/Photo\n";
    std::cout << "11. View My Memories\n";
    std::cout << "12. View Public Memories\n";
    std::cout << "0. Exit\n";
    std::cout << "===============\n";
}

void CLI::createWallet() {
    std::cout << "Creating new wallet..." << std::endl;
    m_wallet = std::make_unique<Wallet>();
    std::cout << "Wallet created successfully!" << std::endl;
    std::cout << "Your wallet address: " << m_wallet->getPublicAddress() << std::endl;
}

void CLI::showWalletAddress() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    std::cout << "Your wallet address: " << m_wallet->getPublicAddress() << std::endl;
}

void CLI::showWalletBalance() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    double balance = m_blockchain.getBalanceOfAddress(m_wallet->getPublicAddress());
    std::cout << "Balance for " << m_wallet->getPublicAddress() << ": " 
              << std::fixed << std::setprecision(2) << balance << " coins" << std::endl;
}

void CLI::createTransaction() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    std::string toAddress;
    double amount;
    
    std::cout << "Enter recipient address: ";
    std::getline(std::cin, toAddress);
    
    std::cout << "Enter amount to send: ";
    std::cin >> amount;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    
    if (amount <= 0) {
        std::cout << "Amount must be greater than 0." << std::endl;
        return;
    }
    
    double balance = m_blockchain.getBalanceOfAddress(m_wallet->getPublicAddress());
    if (balance < amount) {
        std::cout << "Insufficient balance. You have " << balance << " coins." << std::endl;
        return;
    }
    
    try {
        Transaction tx(m_wallet->getPublicAddress(), toAddress, amount);
        tx.signTransaction(m_wallet->getPrivateKey());
        
        m_blockchain.addTransaction(tx);
        std::cout << "Transaction created and added to pending transactions." << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Error creating transaction: " << e.what() << std::endl;
    }
}

void CLI::mineBlock() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    std::cout << "Mining new block... (this may take a while)" << std::endl;
    
    try {
        bool success = m_blockchain.minePendingTransactions(m_wallet->getPublicAddress());
        if (success) {
            std::cout << "Block mined successfully! Mining reward will be available after the next block is mined." << std::endl;
        } else {
            std::cout << "Mining failed." << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Error during mining: " << e.what() << std::endl;
    }
}

void CLI::showBlockchain() {
    const auto& chain = m_blockchain.getChain();
    
    std::cout << "\n===== BLOCKCHAIN =====\n";
    std::cout << "Chain length: " << chain.size() << " blocks\n";
    
    for (const auto& block : chain) {
        std::cout << "\n----- Block #" << block.getIndex() << " -----\n";
        std::cout << "Hash: " << block.getHash() << "\n";
        std::cout << "Previous hash: " << block.getPreviousHash() << "\n";
        std::cout << "Nonce: " << block.getNonce() << "\n";
        
        const auto& txs = block.getTransactions();
        std::cout << "Transactions: " << txs.size() << "\n";
        
        for (size_t i = 0; i < txs.size(); ++i) {
            const auto& tx = txs[i];
            std::cout << "  Transaction " << (i + 1) << ":\n";
            std::cout << "    From: " << (tx.getFromAddress().empty() ? "SYSTEM (Mining Reward)" : tx.getFromAddress()) << "\n";
            std::cout << "    To: " << tx.getToAddress() << "\n";
            std::cout << "    Amount: " << std::fixed << std::setprecision(2) << tx.getAmount() << "\n";
        }
    }
    
    std::cout << "=====================\n";
}

void CLI::showPendingTransactions() {
    const auto& txs = m_blockchain.getPendingTransactions();
    
    std::cout << "\n===== PENDING TRANSACTIONS =====\n";
    std::cout << "Count: " << txs.size() << " transactions\n";
    
    for (size_t i = 0; i < txs.size(); ++i) {
        const auto& tx = txs[i];
        std::cout << "Transaction " << (i + 1) << ":\n";
        std::cout << "  From: " << (tx.getFromAddress().empty() ? "SYSTEM (Mining Reward)" : tx.getFromAddress()) << "\n";
        std::cout << "  To: " << tx.getToAddress() << "\n";
        std::cout << "  Amount: " << std::fixed << std::setprecision(2) << tx.getAmount() << "\n";
    }
    
    std::cout << "================================\n";
}

void CLI::validateBlockchain() {
    bool isValid = m_blockchain.isChainValid();
    
    if (isValid) {
        std::cout << "Blockchain is valid!" << std::endl;
    } else {
        std::cout << "Blockchain is NOT valid!" << std::endl;
    }
}

void CLI::adjustDifficulty() {
    uint32_t currentDifficulty = m_blockchain.getDifficulty();
    uint32_t newDifficulty;
    
    std::cout << "Current difficulty: " << currentDifficulty << std::endl;
    std::cout << "Enter new difficulty (higher = more difficult): ";
    std::cin >> newDifficulty;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    
    if (newDifficulty < 1) {
        std::cout << "Difficulty must be at least 1." << std::endl;
        return;
    }
    
    m_blockchain.setDifficulty(newDifficulty);
    std::cout << "Mining difficulty updated to " << newDifficulty << std::endl;
}

void CLI::uploadMemory() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    // Create memories directory if it doesn't exist
    std::filesystem::create_directories("./data/memories");
    
    std::string filePath;
    std::string title;
    std::string description;
    std::string tagsInput;
    std::string privacyOption;
    bool isPrivate = true;
    
    std::cout << "\n===== UPLOAD MEMORY =====\n";
    std::cout << "Enter file path to upload: ";
    std::getline(std::cin, filePath);
    
    if (!std::filesystem::exists(filePath)) {
        std::cout << "File does not exist: " << filePath << std::endl;
        return;
    }
    
    std::cout << "Enter title for this memory: ";
    std::getline(std::cin, title);
    
    std::cout << "Enter description (optional): ";
    std::getline(std::cin, description);
    
    std::cout << "Enter tags separated by commas (optional): ";
    std::getline(std::cin, tagsInput);
    
    std::cout << "Make this memory private? (y/n): ";
    std::getline(std::cin, privacyOption);
    
    if (privacyOption == "n" || privacyOption == "N") {
        isPrivate = false;
    }
    
    // Parse tags
    std::vector<std::string> tags;
    std::istringstream tagStream(tagsInput);
    std::string tag;
    while (std::getline(tagStream, tag, ',')) {
        // Trim whitespace
        tag.erase(0, tag.find_first_not_of(' '));
        tag.erase(tag.find_last_not_of(' ') + 1);
        if (!tag.empty()) {
            tags.push_back(tag);
        }
    }
    
    try {
        // Read the file
        std::string content = readFileToString(filePath);
        
        if (content.empty()) {
            std::cout << "Error reading file or file is empty." << std::endl;
            return;
        }
        
        // Calculate hash for duplicate detection
        std::string contentHash = calculateMemoryHash(content);
        
        // Check for duplicates
        if (m_memoryStorage->memoryHashExists(contentHash)) {
            std::cout << "This memory already exists on the blockchain. Duplicate uploads are not rewarded." << std::endl;
            return;
        }
        
        // Create the memory object
        Memory memory;
        memory.id = ""; // Will be generated by storage
        memory.ownerAddress = m_wallet->getPublicAddress();
        memory.hash = contentHash;
        memory.encryptedContent = content; // Will be encrypted by storage if private
        memory.contentType = filePath.substr(filePath.find_last_of(".") + 1); // Get file extension
        memory.title = title;
        memory.description = description;
        memory.timestamp = static_cast<uint64_t>(std::time(nullptr));
        memory.rewardAmount = MEMORY_UPLOAD_REWARD;
        memory.tags = tags;
        memory.isPrivate = isPrivate;
        
        // Store the memory
        bool success = m_memoryStorage->storeMemory(memory, *m_wallet);
        
        if (success) {
            std::cout << "Memory uploaded successfully!" << std::endl;
            
            // Process reward for unique memory
            if (processMemoryReward(contentHash)) {
                std::cout << "You've been awarded " << MEMORY_UPLOAD_REWARD 
                          << " coins for your unique memory upload!" << std::endl;
            } else {
                std::cout << "Reward transaction created but requires mining to confirm." << std::endl;
            }
        } else {
            std::cout << "Failed to upload memory." << std::endl;
        }
    } catch (const std::exception& e) {
        std::cout << "Error uploading memory: " << e.what() << std::endl;
    }
}

void CLI::viewMyMemories() {
    if (!m_wallet) {
        std::cout << "No wallet created yet. Please create a wallet first (option 1)." << std::endl;
        return;
    }
    
    std::cout << "\n===== MY MEMORIES =====\n";
    
    try {
        std::vector<Memory> memories = m_memoryStorage->getMemoriesByOwner(
            m_wallet->getPublicAddress(), *m_wallet);
        
        if (memories.empty()) {
            std::cout << "You haven't uploaded any memories yet." << std::endl;
            return;
        }
        
        std::cout << "Total Memories: " << memories.size() << "\n\n";
        
        for (size_t i = 0; i < memories.size(); ++i) {
            const auto& memory = memories[i];
            
            std::cout << "----- Memory #" << (i + 1) << " -----\n";
            std::cout << "ID: " << memory.id << "\n";
            std::cout << "Title: " << memory.title << "\n";
            std::cout << "Description: " << memory.description << "\n";
            std::cout << "Type: " << memory.contentType << "\n";
            std::cout << "Date: " << std::ctime(reinterpret_cast<const time_t*>(&memory.timestamp));
            std::cout << "Privacy: " << (memory.isPrivate ? "Private" : "Public") << "\n";
            std::cout << "Reward: " << memory.rewardAmount << " coins\n";
            
            // Display tags if any
            if (!memory.tags.empty()) {
                std::cout << "Tags: ";
                for (size_t j = 0; j < memory.tags.size(); ++j) {
                    std::cout << memory.tags[j];
                    if (j < memory.tags.size() - 1) {
                        std::cout << ", ";
                    }
                }
                std::cout << "\n";
            }
            
            // Option to view/save the memory
            std::string viewOption;
            std::cout << "Do you want to view/save this memory? (y/n): ";
            std::getline(std::cin, viewOption);
            
            if (viewOption == "y" || viewOption == "Y") {
                std::string filename = "memory_" + memory.id.substr(0, 8) + "." + memory.contentType;
                
                if (saveFileToDisk(memory.encryptedContent, filename)) {
                    std::cout << "Memory saved to: " << filename << std::endl;
                } else {
                    std::cout << "Failed to save memory to disk." << std::endl;
                }
            }
            
            std::cout << "-------------------------\n";
        }
    } catch (const std::exception& e) {
        std::cout << "Error retrieving memories: " << e.what() << std::endl;
    }
}

void CLI::viewPublicMemories() {
    std::cout << "\n===== PUBLIC MEMORIES =====\n";
    
    try {
        std::vector<Memory> memories = m_memoryStorage->getPublicMemories();
        
        if (memories.empty()) {
            std::cout << "No public memories available." << std::endl;
            return;
        }
        
        std::cout << "Total Public Memories: " << memories.size() << "\n\n";
        
        for (size_t i = 0; i < memories.size(); ++i) {
            const auto& memory = memories[i];
            
            std::cout << "----- Memory #" << (i + 1) << " -----\n";
            std::cout << "ID: " << memory.id << "\n";
            std::cout << "Owner: " << memory.ownerAddress << "\n";
            std::cout << "Title: " << memory.title << "\n";
            std::cout << "Description: " << memory.description << "\n";
            std::cout << "Type: " << memory.contentType << "\n";
            std::cout << "Date: " << std::ctime(reinterpret_cast<const time_t*>(&memory.timestamp));
            
            // Display tags if any
            if (!memory.tags.empty()) {
                std::cout << "Tags: ";
                for (size_t j = 0; j < memory.tags.size(); ++j) {
                    std::cout << memory.tags[j];
                    if (j < memory.tags.size() - 1) {
                        std::cout << ", ";
                    }
                }
                std::cout << "\n";
            }
            
            // Note: We don't allow viewing of others' memories, even if public
            // They can only see metadata
            
            std::cout << "-------------------------\n";
        }
    } catch (const std::exception& e) {
        std::cout << "Error retrieving public memories: " << e.what() << std::endl;
    }
}

std::string CLI::readFileToString(const std::string& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file) {
        return "";
    }
    
    // Read the file
    return std::string(
        std::istreambuf_iterator<char>(file),
        std::istreambuf_iterator<char>()
    );
}

std::string CLI::calculateMemoryHash(const std::string& content) {
    // Use the utility function to calculate SHA-256 hash
    return Utils::sha256(content);
}

bool CLI::processMemoryReward(const std::string& memoryHash) {
    if (!m_wallet) {
        return false;
    }
    
    try {
        // Create a reward transaction
        Transaction rewardTx("SYSTEM", m_wallet->getPublicAddress(), MEMORY_UPLOAD_REWARD);
        
        // Add to pending transactions
        m_blockchain.addTransaction(rewardTx);
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error processing memory reward: " << e.what() << std::endl;
        return false;
    }
}

bool CLI::saveFileToDisk(const std::string& content, const std::string& filename) {
    try {
        std::ofstream outFile(filename, std::ios::binary);
        if (!outFile) {
            return false;
        }
        
        outFile.write(content.c_str(), content.size());
        outFile.close();
        
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error saving file: " << e.what() << std::endl;
        return false;
    }
}

void CLI::exit() {
    std::cout << "Exiting application. Goodbye!" << std::endl;
    m_running = false;
}
