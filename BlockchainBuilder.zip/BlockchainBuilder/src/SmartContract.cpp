#include "../include/SmartContract.h"
#include "../include/Blockchain.h"
#include "../include/Transaction.h"
#include "../include/Utils.h"
#include <iostream>
#include <chrono>

// Initialize static members
std::map<std::string, std::function<std::shared_ptr<SmartContract>(const json&)>> SmartContractFactory::contractCreators;

// SmartContract Implementation
SmartContract::SmartContract() : creationTimestamp(0) {
}

SmartContract::SmartContract(const std::string& owner, const json& contractCode) 
    : ownerAddress(owner), code(contractCode) {
    
    // Generate a unique address for the contract
    // In a real implementation, this would be more sophisticated
    auto now = std::chrono::system_clock::now();
    creationTimestamp = std::chrono::duration_cast<std::chrono::seconds>(
        now.time_since_epoch()).count();
    
    // Create contract address as hash of owner + timestamp
    address = Utils::sha256(owner + std::to_string(creationTimestamp));
    
    // Initialize empty state
    state = json::object();
}

bool SmartContract::initialize(const Blockchain& blockchain) {
    // Basic initialization - can be overridden by derived classes
    return true;
}

json SmartContract::execute(const Transaction& transaction, Blockchain& blockchain) {
    // Base implementation - should be overridden by derived classes
    return json{{"status", "error"}, {"message", "Contract execution not implemented"}};
}

bool SmartContract::validateTransaction(const Transaction& transaction, const Blockchain& blockchain) const {
    // Basic validation - can be overridden by derived classes
    // Check if the transaction is signed correctly
    return transaction.isValid();
}

std::string SmartContract::getAddress() const {
    return address;
}

std::string SmartContract::getOwner() const {
    return ownerAddress;
}

json SmartContract::getState() const {
    return state;
}

json SmartContract::getCode() const {
    return code;
}

uint64_t SmartContract::getCreationTimestamp() const {
    return creationTimestamp;
}

json SmartContract::toJson() const {
    json j;
    j["address"] = address;
    j["owner"] = ownerAddress;
    j["state"] = state;
    j["code"] = code;
    j["creationTimestamp"] = creationTimestamp;
    j["type"] = "basic"; // For type identification
    return j;
}

std::shared_ptr<SmartContract> SmartContract::fromJson(const json& j) {
    // Check contract type and delegate to appropriate creator
    if (j.contains("type")) {
        std::string type = j["type"];
        return SmartContractFactory::createContract(type, j);
    }
    
    // Default to basic contract
    auto contract = std::make_shared<SmartContract>();
    contract->address = j["address"];
    contract->ownerAddress = j["owner"];
    contract->state = j["state"];
    contract->code = j["code"];
    contract->creationTimestamp = j["creationTimestamp"];
    return contract;
}

// TokenContract Implementation
TokenContract::TokenContract(const std::string& owner,
                           const std::string& name,
                           const std::string& symbol,
                           uint64_t initialSupply)
    : SmartContract(owner, json{{"type", "token"}}),
      tokenName(name),
      tokenSymbol(symbol),
      totalSupply(initialSupply) {
    
    // Initial state setup
    state["name"] = name;
    state["symbol"] = symbol;
    state["totalSupply"] = initialSupply;
    
    // All tokens initially assigned to contract creator
    balances[owner] = initialSupply;
    state["balances"] = json::object();
    state["balances"][owner] = initialSupply;
}

bool TokenContract::initialize(const Blockchain& blockchain) {
    // Token contracts are initialized with total supply to the creator
    std::cout << "Initializing token contract: " << tokenName << " (" << tokenSymbol << ")" << std::endl;
    std::cout << "Total supply: " << totalSupply << " assigned to " << ownerAddress << std::endl;
    return true;
}

json TokenContract::execute(const Transaction& transaction, Blockchain& blockchain) {
    // Parse transaction data - expecting JSON format with "action" field
    json txData;
    try {
        if (!transaction.getData().empty()) {
            txData = json::parse(transaction.getData());
        } else {
            return json{{"status", "error"}, {"message", "No transaction data provided"}};
        }
    } catch (const json::exception& e) {
        return json{{"status", "error"}, {"message", "Invalid transaction data format"}};
    }
    
    // Check for required action field
    if (!txData.contains("action")) {
        return json{{"status", "error"}, {"message", "No action specified in transaction data"}};
    }
    
    std::string action = txData["action"];
    
    // Execute appropriate action
    if (action == "transfer") {
        // Validate required fields
        if (!txData.contains("to") || !txData.contains("amount")) {
            return json{{"status", "error"}, {"message", "Transfer requires 'to' and 'amount' fields"}};
        }
        
        std::string from = transaction.getFromAddress();
        std::string to = txData["to"];
        uint64_t amount = txData["amount"];
        
        if (transfer(from, to, amount)) {
            return json{{"status", "success"}, {"action", "transfer"}, {"from", from}, {"to", to}, {"amount", amount}};
        } else {
            return json{{"status", "error"}, {"message", "Transfer failed - insufficient balance or invalid address"}};
        }
    }
    else if (action == "balanceOf") {
        // Get balance of an address
        std::string address = txData.contains("address") ? txData["address"].get<std::string>() : transaction.getFromAddress();
        uint64_t balance = balanceOf(address);
        return json{{"status", "success"}, {"action", "balanceOf"}, {"address", address}, {"balance", balance}};
    }
    
    return json{{"status", "error"}, {"message", "Unknown action: " + action}};
}

bool TokenContract::validateTransaction(const Transaction& transaction, const Blockchain& blockchain) const {
    // First, validate basic transaction properties
    if (!SmartContract::validateTransaction(transaction, blockchain)) {
        return false;
    }
    
    try {
        // Parse transaction data
        json txData = json::parse(transaction.getData());
        
        // Check action
        if (!txData.contains("action")) {
            return false;
        }
        
        std::string action = txData["action"];
        
        if (action == "transfer") {
            // Check for required fields
            if (!txData.contains("to") || !txData.contains("amount")) {
                return false;
            }
            
            // Check for valid amount
            uint64_t amount = txData["amount"];
            if (amount <= 0) {
                return false;
            }
            
            // Check if sender has enough balance
            std::string from = transaction.getFromAddress();
            if (balanceOf(from) < amount) {
                return false;
            }
        }
        
        return true;
    } catch (const json::exception& e) {
        return false;
    }
}

bool TokenContract::transfer(const std::string& from, const std::string& to, uint64_t amount) {
    // Validate addresses and amount
    if (from.empty() || to.empty() || amount <= 0) {
        return false;
    }
    
    // Check for sufficient balance
    if (balances.find(from) == balances.end() || balances[from] < amount) {
        return false;
    }
    
    // Update balances
    balances[from] -= amount;
    balances[to] += amount;
    
    // Update state
    state["balances"][from] = balances[from];
    state["balances"][to] = balances[to];
    
    return true;
}

uint64_t TokenContract::balanceOf(const std::string& address) const {
    auto it = balances.find(address);
    if (it != balances.end()) {
        return it->second;
    }
    return 0;
}

json TokenContract::toJson() const {
    json j = SmartContract::toJson();
    j["type"] = "token";
    j["tokenName"] = tokenName;
    j["tokenSymbol"] = tokenSymbol;
    j["totalSupply"] = totalSupply;
    
    // Store balances
    j["balances"] = json::object();
    for (const auto& [address, balance] : balances) {
        j["balances"][address] = balance;
    }
    
    return j;
}

std::shared_ptr<TokenContract> TokenContract::fromJson(const json& j) {
    // Create token contract
    auto contract = std::make_shared<TokenContract>(
        j["owner"],
        j["tokenName"],
        j["tokenSymbol"],
        j["totalSupply"]
    );
    
    // Restore address and timestamp
    contract->address = j["address"];
    contract->creationTimestamp = j["creationTimestamp"];
    
    // Restore state
    contract->state = j["state"];
    
    // Restore balances
    contract->balances.clear();
    for (auto it = j["balances"].begin(); it != j["balances"].end(); ++it) {
        contract->balances[it.key()] = it.value();
    }
    
    return contract;
}

// SmartContractFactory Implementation
void SmartContractFactory::initialize() {
    // Register standard contract types
    registerContractType("basic", [](const json& j) -> std::shared_ptr<SmartContract> {
        return std::make_shared<SmartContract>();
    });
    
    registerContractType("token", [](const json& j) -> std::shared_ptr<SmartContract> {
        return TokenContract::fromJson(j);
    });
}

std::shared_ptr<SmartContract> SmartContractFactory::createContract(const std::string& type, const json& params) {
    auto it = contractCreators.find(type);
    if (it != contractCreators.end()) {
        return it->second(params);
    }
    
    // Default to basic contract if type not found
    std::cout << "Unknown contract type: " << type << ". Creating basic contract." << std::endl;
    return std::make_shared<SmartContract>();
}

void SmartContractFactory::registerContractType(const std::string& type, ContractCreator creator) {
    contractCreators[type] = creator;
}