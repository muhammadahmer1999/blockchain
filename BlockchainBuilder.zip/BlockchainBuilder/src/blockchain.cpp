/**
 * @file blockchain.cpp
 * @brief Implementation of the Blockchain class
 */

#include "blockchain.h"
#include <iostream>
#include <chrono>
#include <stdexcept>

Blockchain::Blockchain(int difficulty, double miningReward, bool isMainnet, const std::string& networkId)
    : m_difficulty(static_cast<uint32_t>(difficulty)), 
      m_miningReward(miningReward),
      m_isMainnet(isMainnet),
      m_networkId(networkId) {
    // Create the genesis block
    m_chain.push_back(createGenesisBlock());
    
    std::cout << "Blockchain initialized with:" << std::endl;
    std::cout << "  Network: " << (m_isMainnet ? "Mainnet" : "Testnet") << std::endl;
    std::cout << "  Network ID: " << m_networkId << std::endl;
    std::cout << "  Difficulty: " << m_difficulty << std::endl;
    std::cout << "  Mining reward: " << m_miningReward << std::endl;
}

Block Blockchain::createGenesisBlock() const {
    // Current timestamp
    auto timestamp = std::chrono::system_clock::now();
    
    // Create an empty transaction for the genesis block
    std::vector<Transaction> transactions;
    
    // Create and return the genesis block
    return Block(0, timestamp, transactions, "0");
}

const Block& Blockchain::getLatestBlock() const {
    std::lock_guard<std::mutex> lock(m_chainMutex);
    return m_chain.back();
}

bool Blockchain::addTransaction(const Transaction& transaction) {
    // Basic transaction validation
    if (transaction.getFromAddress().empty() && transaction.getToAddress().empty()) {
        throw std::invalid_argument("Transaction must have at least a from or to address");
    }
    
    if (transaction.getAmount() <= 0) {
        throw std::invalid_argument("Transaction amount must be greater than 0");
    }
    
    // If it's not a mining reward, validate sender has enough balance
    if (!transaction.getFromAddress().empty()) {
        double balance = getBalanceOfAddress(transaction.getFromAddress());
        if (balance < transaction.getAmount()) {
            throw std::invalid_argument("Not enough balance");
        }
        
        // Verify signature (simplified in this implementation)
        if (!transaction.isValid()) {
            throw std::invalid_argument("Cannot add invalid transaction to chain");
        }
    }
    
    // Add the transaction to pending transactions
    std::lock_guard<std::mutex> lock(m_pendingTransactionsMutex);
    m_pendingTransactions.push_back(transaction);
    return true;
}

bool Blockchain::minePendingTransactions(const std::string& minerAddress) {
    // Create a reward transaction
    Transaction rewardTx("", minerAddress, m_miningReward);
    
    // Copy pending transactions to a local variable
    std::vector<Transaction> transactions;
    {
        std::lock_guard<std::mutex> lock(m_pendingTransactionsMutex);
        transactions = m_pendingTransactions;
        m_pendingTransactions.clear();
    }
    
    // Add the reward transaction
    transactions.push_back(rewardTx);
    
    // Get the latest block
    const Block& latestBlock = getLatestBlock();
    
    // Create a new block
    auto timestamp = std::chrono::system_clock::now();
    Block newBlock(latestBlock.getIndex() + 1, timestamp, transactions, latestBlock.getHash());
    
    // Mine the block
    std::cout << "Mining block..." << std::endl;
    newBlock.mineBlock(m_difficulty);
    
    // Add the block to the chain
    {
        std::lock_guard<std::mutex> lock(m_chainMutex);
        m_chain.push_back(newBlock);
    }
    
    std::cout << "Block successfully mined!" << std::endl;
    return true;
}

bool Blockchain::isChainValid() const {
    std::lock_guard<std::mutex> lock(m_chainMutex);
    
    // Check if the chain has at least one block
    if (m_chain.empty()) {
        return false;
    }
    
    // Loop through the chain to check hashes
    for (size_t i = 1; i < m_chain.size(); i++) {
        const Block& currentBlock = m_chain[i];
        const Block& previousBlock = m_chain[i - 1];
        
        // Check if current block hash is valid
        if (currentBlock.getHash() != currentBlock.calculateHash()) {
            std::cout << "Invalid hash on block " << i << std::endl;
            return false;
        }
        
        // Check if the previous hash reference is correct
        if (currentBlock.getPreviousHash() != previousBlock.getHash()) {
            std::cout << "Invalid previous hash reference on block " << i << std::endl;
            return false;
        }
        
        // Validate all transactions in the block
        for (const auto& tx : currentBlock.getTransactions()) {
            if (!tx.isValid()) {
                std::cout << "Invalid transaction found in block " << i << std::endl;
                return false;
            }
        }
    }
    
    return true;
}

double Blockchain::getBalanceOfAddress(const std::string& address) const {
    double balance = 0;
    
    std::lock_guard<std::mutex> lock(m_chainMutex);
    for (const auto& block : m_chain) {
        for (const auto& tx : block.getTransactions()) {
            if (tx.getFromAddress() == address) {
                balance -= tx.getAmount();
            }
            
            if (tx.getToAddress() == address) {
                balance += tx.getAmount();
            }
        }
    }
    
    return balance;
}

const std::vector<Block>& Blockchain::getChain() const {
    std::lock_guard<std::mutex> lock(m_chainMutex);
    return m_chain;
}

const std::vector<Transaction>& Blockchain::getPendingTransactions() const {
    std::lock_guard<std::mutex> lock(m_pendingTransactionsMutex);
    return m_pendingTransactions;
}

void Blockchain::setDifficulty(uint32_t newDifficulty) {
    m_difficulty = newDifficulty;
}

uint32_t Blockchain::getDifficulty() const {
    return m_difficulty;
}

double Blockchain::getMiningReward() const {
    return m_miningReward;
}

void Blockchain::setMiningReward(double reward) {
    m_miningReward = reward;
}

bool Blockchain::isMainnet() const {
    return m_isMainnet;
}

std::string Blockchain::getNetworkId() const {
    return m_networkId;
}
