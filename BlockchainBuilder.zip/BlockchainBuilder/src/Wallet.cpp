#include "../include/Wallet.h"
#include "../include/Utils.h"
#include <cryptopp/base64.h>
#include <cryptopp/hex.h>
#include <cryptopp/filters.h>
#include <iostream>

Wallet::Wallet() {
    generateKeyPair();
}

void Wallet::generateKeyPair() {
    CryptoPP::AutoSeededRandomPool prng;
    
    CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PrivateKey privateKeyObj;
    privateKeyObj.Initialize(prng, CryptoPP::ASN1::secp256k1());
    
    // Convert private key to string
    CryptoPP::HexEncoder encoder;
    std::string privateKeyHex;
    encoder.Attach(new CryptoPP::StringSink(privateKeyHex));
    privateKeyObj.Save(encoder);
    encoder.MessageEnd();
    this->privateKey = privateKeyHex;
    
    // Generate corresponding public key
    CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PublicKey publicKeyObj;
    privateKeyObj.MakePublicKey(publicKeyObj);
    
    // Convert public key to string
    std::string publicKeyHex;
    encoder.Attach(new CryptoPP::StringSink(publicKeyHex));
    publicKeyObj.Save(encoder);
    encoder.MessageEnd();
    this->publicKey = publicKeyHex;
}

std::string Wallet::sign(const std::string& data) const {
    // Convert the private key from string back to object
    CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PrivateKey privateKeyObj;
    CryptoPP::HexDecoder decoder;
    decoder.Put((CryptoPP::byte*)privateKey.data(), privateKey.size());
    decoder.MessageEnd();
    privateKeyObj.Load(decoder);
    
    // Create signer object
    CryptoPP::AutoSeededRandomPool prng;
    CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::Signer signer(privateKeyObj);
    
    // Sign the data
    std::string signature;
    CryptoPP::StringSource ss1(data, true,
        new CryptoPP::SignerFilter(prng, signer,
            new CryptoPP::HexEncoder(
                new CryptoPP::StringSink(signature)
            )
        )
    );
    
    return signature;
}

bool Wallet::verify(const std::string& publicKey, const std::string& data, const std::string& signature) {
    try {
        // Convert the public key from string back to object
        CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PublicKey publicKeyObj;
        CryptoPP::HexDecoder decoder;
        decoder.Put((CryptoPP::byte*)publicKey.data(), publicKey.size());
        decoder.MessageEnd();
        publicKeyObj.Load(decoder);
        
        // Create verifier object
        CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::Verifier verifier(publicKeyObj);
        
        // Verify the signature
        bool result = false;
        CryptoPP::StringSource ss(
            signature + data,  // signature comes first, then data
            true,
            new CryptoPP::HexDecoder(
                new CryptoPP::SignatureVerificationFilter(
                    verifier,
                    new CryptoPP::ArraySink((CryptoPP::byte*)&result, sizeof(result))
                )
            )
        );
        
        return result;
    } catch (const CryptoPP::Exception& e) {
        std::cerr << "Verification error: " << e.what() << std::endl;
        return false;
    }
}

Wallet Wallet::fromPrivateKey(const std::string& privateKeyHex) {
    Wallet wallet;
    
    try {
        // Set the private key
        wallet.privateKey = privateKeyHex;
        
        // Recreate the public key from the private key
        CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PrivateKey privateKeyObj;
        CryptoPP::HexDecoder decoder;
        decoder.Put((CryptoPP::byte*)privateKeyHex.data(), privateKeyHex.size());
        decoder.MessageEnd();
        privateKeyObj.Load(decoder);
        
        // Generate corresponding public key
        CryptoPP::ECDSA<CryptoPP::ECP, CryptoPP::SHA256>::PublicKey publicKeyObj;
        privateKeyObj.MakePublicKey(publicKeyObj);
        
        // Convert public key to string
        std::string publicKeyHex;
        CryptoPP::HexEncoder encoder;
        encoder.Attach(new CryptoPP::StringSink(publicKeyHex));
        publicKeyObj.Save(encoder);
        encoder.MessageEnd();
        wallet.publicKey = publicKeyHex;
    } catch (const CryptoPP::Exception& e) {
        std::cerr << "Error loading private key: " << e.what() << std::endl;
    }
    
    return wallet;
}
