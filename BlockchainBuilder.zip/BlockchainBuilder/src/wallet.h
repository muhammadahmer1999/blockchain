/**
 * @file wallet.h
 * @brief Definition of the Wallet class
 */

#pragma once

#include <string>
#include <vector>
#include <memory>

/**
 * @class Wallet
 * @brief Represents a wallet that can create and sign transactions
 */
class Wallet {
public:
    /**
     * @brief Constructor that creates a new wallet with a keypair
     */
    Wallet();

    /**
     * @brief Get the wallet's public address
     * @return Public address as a string
     */
    std::string getPublicAddress() const;

    /**
     * @brief Sign data with the wallet's private key
     * @param dataToSign The data to sign
     * @return The signature
     */
    std::string sign(const std::string& dataToSign) const;

    /**
     * @brief Get the raw private key data
     * @return Vector containing the private key bytes
     */
    const std::vector<uint8_t>& getPrivateKey() const;

private:
    std::vector<uint8_t> m_privateKey;
    std::vector<uint8_t> m_publicKey;
    std::string m_publicAddress;

    /**
     * @brief Generate a keypair for the wallet
     */
    void generateKeypair();
};
