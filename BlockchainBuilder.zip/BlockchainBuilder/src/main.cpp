/**
 * @file main.cpp
 * @brief Main entry point for the Ahmiyat Blockchain application
 */

#include "cli.h"
#include "blockchain.h"
#include "../include/Storage.h"
#include "../include/MemPool.h"
#include "../include/Sharding.h"
#include "../include/API.h"
#include <iostream>
#include <string>
#include <thread>
#include <filesystem>
#include <chrono>
#include <csignal>

// Global variables for graceful shutdown
bool g_running = true;
std::unique_ptr<APIServer> g_apiServer;
std::unique_ptr<LevelDBStorage> g_storage;
std::unique_ptr<MemPool> g_mempool;
std::unique_ptr<ShardManager> g_shardManager;
std::unique_ptr<Blockchain> g_blockchain;
std::unique_ptr<CLI> g_cli;

// Paths for various data directories
const std::string DATA_DIR = "./data";
const std::string BLOCKCHAIN_DIR = DATA_DIR + "/blockchain_data";
const std::string MEMORY_FRAGMENTS_DIR = DATA_DIR + "/memories";
const std::string CERTS_DIR = DATA_DIR + "/certs";

// Signal handler for graceful shutdown
void signalHandler(int signal) {
    std::cout << "Received signal " << signal << ", shutting down..." << std::endl;
    g_running = false;
}

// Create necessary directories
void createDirectories() {
    std::filesystem::create_directories(DATA_DIR);
    std::filesystem::create_directories(BLOCKCHAIN_DIR);
    std::filesystem::create_directories(MEMORY_FRAGMENTS_DIR);
    std::filesystem::create_directories(CERTS_DIR);
    
    std::cout << "Created data directories" << std::endl;
}

// Initialize storage
bool initializeStorage() {
    try {
        g_storage = std::make_unique<LevelDBStorage>();
        bool success = g_storage->open(BLOCKCHAIN_DIR);
        
        if (!success) {
            std::cerr << "Failed to open LevelDB storage at " << BLOCKCHAIN_DIR << std::endl;
            return false;
        }
        
        std::cout << "Initialized blockchain storage" << std::endl;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "Error initializing storage: " << e.what() << std::endl;
        return false;
    }
}

// Clean up resources
void cleanup() {
    // Stop API server
    if (g_apiServer) {
        std::cout << "Stopping API server..." << std::endl;
        g_apiServer->stop();
    }
    
    // Close storage
    if (g_storage) {
        std::cout << "Closing blockchain storage..." << std::endl;
        g_storage->close();
    }
    
    std::cout << "Shutdown complete" << std::endl;
}

// Main entry point
int main(int argc, char* argv[]) {
    try {
        // Process command line arguments
        int apiPort = 8080;
        bool enableAPI = true;
        bool enableCLI = true;
        int shardCount = 16;
        bool isMainnet = false;
        int difficulty = 4;  // Default difficulty for testnet
        double miningReward = 50.0;  // Default mining reward for testnet
        std::string networkId = "testnet";  // Default to testnet environment
        
        for (int i = 1; i < argc; i++) {
            std::string arg = argv[i];
            
            if (arg == "--port" && i + 1 < argc) {
                apiPort = std::stoi(argv[++i]);
            } else if (arg == "--no-api") {
                enableAPI = false;
            } else if (arg == "--no-cli") {
                enableCLI = false;
            } else if (arg == "--shards" && i + 1 < argc) {
                shardCount = std::stoi(argv[++i]);
                if (shardCount <= 0) {
                    std::cerr << "Invalid shard count, using default (16)" << std::endl;
                    shardCount = 16;
                }
            } else if (arg == "--mainnet" || arg == "--production") {
                isMainnet = true;
                difficulty = 5;  // Higher difficulty for mainnet
                miningReward = 25.0;  // Lower mining reward for mainnet
                networkId = "mainnet";
                std::cout << "Running in MAINNET mode" << std::endl;
            } else if (arg == "--difficulty" && i + 1 < argc) {
                difficulty = std::stoi(argv[++i]);
                if (difficulty <= 0) {
                    std::cerr << "Invalid difficulty, using default" << std::endl;
                    difficulty = isMainnet ? 5 : 4;
                }
            } else if (arg == "--mining-reward" && i + 1 < argc) {
                miningReward = std::stod(argv[++i]);
                if (miningReward <= 0) {
                    std::cerr << "Invalid mining reward, using default" << std::endl;
                    miningReward = isMainnet ? 25.0 : 50.0;
                }
            } else if (arg == "--network-id" && i + 1 < argc) {
                networkId = argv[++i];
                if (networkId.empty()) {
                    networkId = isMainnet ? "mainnet" : "testnet";
                }
            } else if (arg == "--help") {
                std::cout << "Ahmiyat Blockchain v1.0.0" << std::endl;
                std::cout << "Usage: ahmiyat [options]" << std::endl;
                std::cout << "Options:" << std::endl;
                std::cout << "  --port <port>           API server port (default: 8080)" << std::endl;
                std::cout << "  --no-api                Disable API server" << std::endl;
                std::cout << "  --no-cli                Disable CLI interface" << std::endl;
                std::cout << "  --shards <count>        Number of shards (default: 16)" << std::endl;
                std::cout << "  --mainnet               Enable mainnet mode (production)" << std::endl;
                std::cout << "  --production            Same as --mainnet, for convenience" << std::endl;
                std::cout << "  --difficulty <value>    Set mining difficulty (default: 4, mainnet: 5)" << std::endl;
                std::cout << "  --mining-reward <value> Set mining reward (default: 50.0, mainnet: 25.0)" << std::endl;
                std::cout << "  --network-id <id>       Set network ID (default: testnet, mainnet: mainnet)" << std::endl;
                std::cout << "  --help                  Show this help message" << std::endl;
                return 0;
            }
        }
        
        // Set up signal handlers for graceful shutdown
        std::signal(SIGINT, signalHandler);
        std::signal(SIGTERM, signalHandler);
        
        // Create data directories
        createDirectories();
        
        // Initialize storage
        if (!initializeStorage()) {
            return 1;
        }
        
        // Initialize components with mainnet configuration if needed
        g_mempool = std::make_unique<MemPool>(isMainnet);
        g_shardManager = std::make_unique<ShardManager>(shardCount, isMainnet);
        
        // Initialize blockchain
        std::cout << "Initializing Ahmiyat Blockchain..." << std::endl;
        g_blockchain = std::make_unique<Blockchain>(difficulty, miningReward, isMainnet, networkId);
        
        // Blockchain is already initialized with command line parameters in constructor
        
        // Store network ID in a global config (to be used by other components)
        g_storage->put("config:network_id", networkId);
        g_storage->put("config:is_mainnet", isMainnet ? "true" : "false");
        
        // Display network mode
        std::cout << "Network mode: " << (isMainnet ? "MAINNET" : "TESTNET") << std::endl;
        std::cout << "Network ID: " << networkId << std::endl;
        std::cout << "Difficulty: " << difficulty << std::endl;
        std::cout << "Mining reward: " << miningReward << std::endl;
        std::cout << "Shard count: " << shardCount << std::endl;
        
        // Try to load blockchain state from storage
        if (g_storage->loadChainState(*g_blockchain)) {
            std::cout << "Loaded blockchain state from storage" << std::endl;
        } else {
            std::cout << "No existing blockchain state found, starting fresh" << std::endl;
        }
        
        // Start API server if enabled
        if (enableAPI) {
            std::cout << "Starting API server on port " << apiPort << "..." << std::endl;
            g_apiServer = std::make_unique<APIServer>(*g_blockchain, apiPort);
            
            // Configure HTTPS if certificate files exist
            std::string certFile = CERTS_DIR + "/cert.pem";
            std::string keyFile = CERTS_DIR + "/key.pem";
            
            if (std::filesystem::exists(certFile) && std::filesystem::exists(keyFile)) {
                std::cout << "Found SSL certificates, enabling HTTPS" << std::endl;
                g_apiServer->setHTTPS(true, certFile, keyFile);
            }
            
            if (!g_apiServer->start()) {
                std::cerr << "Failed to start API server" << std::endl;
                return 1;
            }
        }
        
        // Start CLI if enabled
        if (enableCLI) {
            std::cout << "Starting command-line interface..." << std::endl;
            g_cli = std::make_unique<CLI>(*g_blockchain);
            g_cli->run();
        } else {
            // If CLI is disabled, keep the application running until signal
            std::cout << "Ahmiyat Blockchain is running (press Ctrl+C to stop)" << std::endl;
            
            while (g_running) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }
        
        // Cleanup and exit
        cleanup();
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "Unknown fatal error occurred" << std::endl;
        return 1;
    }
}
