#include "../include/MemoryStorage.h"
#include "../src/utils.h"
#include <iostream>
#include <ctime>
#include <random>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <thread>
#include <chrono>
#include <leveldb/write_batch.h>

// Define static constants
const std::string MemoryStorage::MEMORY_PREFIX = "memory:";
const std::string MemoryStorage::HASH_INDEX_PREFIX = "hash_index:";
const std::string MemoryStorage::OWNER_INDEX_PREFIX = "owner_index:";

// Default constructor
MemoryStorage::MemoryStorage() : m_db(nullptr) {
    m_dbPath = "data/memories";
    initialize(m_dbPath);
}

// Constructor with specific path
MemoryStorage::MemoryStorage(const std::string& dbPath) : m_db(nullptr), m_dbPath(dbPath) {
    initialize(m_dbPath);
}

// Destructor
MemoryStorage::~MemoryStorage() {
    close();
}

// Initialize the storage
bool MemoryStorage::initialize(const std::string& path) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (m_db) {
        return true;  // Already initialized
    }
    
    m_dbPath = path;
    leveldb::Options options;
    options.create_if_missing = true;
    
    // Create necessary directories
    try {
        std::filesystem::create_directories(path);
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Failed to create directory: " << e.what() << std::endl;
    }
    
    // Check for stale lock file
    std::string lockFile = path + "/LOCK";
    if (std::filesystem::exists(lockFile)) {
        std::cout << "MemoryStorage: Found stale lock file, attempting to remove..." << std::endl;
        try {
            std::filesystem::remove(lockFile);
        } catch (const std::exception& e) {
            std::cerr << "MemoryStorage: Failed to remove lock file: " << e.what() << std::endl;
        }
    }
    
    // Try with recovery option if database exists
    if (std::filesystem::exists(path)) {
        leveldb::Options recoveryOptions;
        recoveryOptions.create_if_missing = false;
        recoveryOptions.error_if_exists = false;
        recoveryOptions.paranoid_checks = true;
        
        leveldb::Status status = leveldb::RepairDB(path, recoveryOptions);
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Repair attempt failed: " << status.ToString() << std::endl;
        } else {
            std::cout << "MemoryStorage: Database repair was successful" << std::endl;
        }
    }
    
    // Now attempt normal open
    int retries = 3;
    leveldb::Status status;
    leveldb::DB* dbPtr = nullptr;
    
    while (retries > 0) {
        status = leveldb::DB::Open(options, path, &dbPtr);
        if (status.ok()) {
            m_db.reset(dbPtr);
            break;
        } else {
            std::cerr << "MemoryStorage: Failed to open database (attempt "
                      << (4 - retries) << "/3): " << status.ToString() << std::endl;
            // Wait a bit before retrying
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            retries--;
        }
    }
    
    if (!status.ok()) {
        std::cerr << "MemoryStorage: All attempts to open database failed: " << status.ToString() << std::endl;
        return false;
    }
    
    std::cout << "MemoryStorage: Successfully opened database at " << path << std::endl;
    return true;
}

// Close the storage
void MemoryStorage::close() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    if (m_db) {
        m_db.reset();
    }
}

// Store a new memory
bool MemoryStorage::storeMemory(Memory& memory, const Wallet& wallet) {
    if (!m_db) return false;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // Check if memory hash already exists (duplicate)
        if (memoryHashExists(memory.hash)) {
            std::cerr << "MemoryStorage: Memory with this content already exists" << std::endl;
            return false;
        }
        
        // Generate a unique ID if not provided
        if (memory.id.empty()) {
            memory.id = generateUniqueId();
        }
        
        // Encrypt content if necessary
        if (!memory.encryptedContent.empty() && !memory.isPrivate) {
            // Only encrypt if it's private
            // For better security, we would use proper encryption here
            memory.encryptedContent = encryptContent(memory.encryptedContent, wallet);
        }
        
        // Set timestamp if not provided
        if (memory.timestamp == 0) {
            memory.timestamp = static_cast<uint64_t>(std::time(nullptr));
        }
        
        // Set owner address
        memory.ownerAddress = wallet.getPublicAddress();
        
        // Serialize to JSON
        json memoryJson;
        memoryJson["id"] = memory.id;
        memoryJson["ownerAddress"] = memory.ownerAddress;
        memoryJson["hash"] = memory.hash;
        memoryJson["encryptedContent"] = memory.encryptedContent;
        memoryJson["contentType"] = memory.contentType;
        memoryJson["category"] = memory.category;
        memoryJson["title"] = memory.title;
        memoryJson["description"] = memory.description;
        memoryJson["timestamp"] = memory.timestamp;
        memoryJson["rewardAmount"] = memory.rewardAmount;
        memoryJson["tags"] = memory.tags;
        memoryJson["isPrivate"] = memory.isPrivate;
        memoryJson["latitude"] = memory.latitude;
        memoryJson["longitude"] = memory.longitude;
        memoryJson["location"] = memory.location;
        
        std::string serializedMemory = memoryJson.dump();
        
        // Write to database
        leveldb::WriteBatch batch;
        
        // Main memory entry
        batch.Put(memoryKey(memory.id), serializedMemory);
        
        // Hash index for duplicate detection
        batch.Put(hashIndexKey(memory.hash), memory.id);
        
        // Owner index for retrieval by owner
        batch.Put(ownerIndexKey(memory.ownerAddress, memory.id), "");
        
        leveldb::Status status = m_db->Write(leveldb::WriteOptions(), &batch);
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Failed to store memory: " << status.ToString() << std::endl;
            return false;
        }
        
        std::cout << "MemoryStorage: Successfully stored memory with ID: " << memory.id << std::endl;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in storeMemory: " << e.what() << std::endl;
        return false;
    }
}

// Retrieve a memory by ID
Memory MemoryStorage::getMemory(const std::string& id, const Wallet& wallet) {
    Memory memory; // Empty memory to return if not found or not accessible
    if (!m_db) return memory;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        std::string serializedMemory;
        leveldb::Status status = m_db->Get(leveldb::ReadOptions(), memoryKey(id), &serializedMemory);
        
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Memory not found with ID: " << id << std::endl;
            return memory;
        }
        
        // Deserialize from JSON
        json memoryJson = json::parse(serializedMemory);
        
        memory.id = memoryJson["id"];
        memory.ownerAddress = memoryJson["ownerAddress"];
        memory.hash = memoryJson["hash"];
        memory.encryptedContent = memoryJson["encryptedContent"];
        memory.contentType = memoryJson["contentType"];
        memory.title = memoryJson["title"];
        memory.description = memoryJson["description"];
        memory.timestamp = memoryJson["timestamp"];
        memory.rewardAmount = memoryJson["rewardAmount"];
        memory.tags = memoryJson["tags"].get<std::vector<std::string>>();
        memory.isPrivate = memoryJson["isPrivate"];
        
        // Load category and location data if available
        if (memoryJson.contains("category")) {
            memory.category = memoryJson["category"];
        }
        if (memoryJson.contains("latitude")) {
            memory.latitude = memoryJson["latitude"];
        }
        if (memoryJson.contains("longitude")) {
            memory.longitude = memoryJson["longitude"];
        }
        if (memoryJson.contains("location")) {
            memory.location = memoryJson["location"];
        }
        
        // Check if the memory is private and the user is not the owner
        if (memory.isPrivate && !isMemoryOwner(memory.ownerAddress, wallet)) {
            std::cerr << "MemoryStorage: Access denied - private memory can only be accessed by owner" << std::endl;
            return Memory(); // Return an empty memory
        }
        
        // Decrypt content if memory is private and user is the owner
        if (memory.isPrivate && !memory.encryptedContent.empty() && isMemoryOwner(memory.ownerAddress, wallet)) {
            try {
                std::string decryptedContent = decryptContent(memory.encryptedContent, wallet);
                memory.encryptedContent = decryptedContent; // Replace with decrypted content
            } catch (const std::exception& e) {
                std::cerr << "MemoryStorage: Failed to decrypt memory content: " << e.what() << std::endl;
                // Keep the encrypted content
            }
        }
        
        return memory;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in getMemory: " << e.what() << std::endl;
        return memory;
    }
}

// Check if a memory hash exists (for duplicate detection)
bool MemoryStorage::memoryHashExists(const std::string& hash) {
    if (!m_db) return false;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::string value;
    leveldb::Status status = m_db->Get(leveldb::ReadOptions(), hashIndexKey(hash), &value);
    
    return status.ok();
}

// Get all memories owned by a wallet address
std::vector<Memory> MemoryStorage::getMemoriesByOwner(const std::string& walletAddress, const Wallet& wallet) {
    std::vector<Memory> memories;
    if (!m_db) return memories;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // Iterate through owner index to find all memories owned by this address
        std::unique_ptr<leveldb::Iterator> it(m_db->NewIterator(leveldb::ReadOptions()));
        
        // Create the prefix for the owner's keys
        std::string ownerPrefix = OWNER_INDEX_PREFIX + walletAddress + ":";
        
        for (it->Seek(ownerPrefix); it->Valid() && Utils::startsWith(it->key().ToString(), ownerPrefix); it->Next()) {
            // Extract memory ID from key
            std::string key = it->key().ToString();
            std::string memoryId = key.substr(ownerPrefix.length());
            
            // Load the memory
            Memory memory = getMemory(memoryId, wallet);
            
            // Only add if it's a valid memory (has an ID)
            if (!memory.id.empty()) {
                memories.push_back(memory);
            }
        }
        
        return memories;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in getMemoriesByOwner: " << e.what() << std::endl;
        return memories;
    }
}

// Get all public memories
std::vector<Memory> MemoryStorage::getPublicMemories() {
    std::vector<Memory> memories;
    if (!m_db) return memories;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // Iterate through all memories
        std::unique_ptr<leveldb::Iterator> it(m_db->NewIterator(leveldb::ReadOptions()));
        
        for (it->Seek(MEMORY_PREFIX); it->Valid() && Utils::startsWith(it->key().ToString(), MEMORY_PREFIX); it->Next()) {
            try {
                json memoryJson = json::parse(it->value().ToString());
                
                // Skip private memories
                if (memoryJson["isPrivate"]) {
                    continue;
                }
                
                Memory memory;
                memory.id = memoryJson["id"];
                memory.ownerAddress = memoryJson["ownerAddress"];
                memory.hash = memoryJson["hash"];
                memory.encryptedContent = memoryJson["encryptedContent"];
                memory.contentType = memoryJson["contentType"];
                memory.title = memoryJson["title"];
                memory.description = memoryJson["description"];
                memory.timestamp = memoryJson["timestamp"];
                memory.rewardAmount = memoryJson["rewardAmount"];
                memory.tags = memoryJson["tags"].get<std::vector<std::string>>();
                memory.isPrivate = false;
                
                // Load additional fields if present
                if (memoryJson.contains("category")) {
                    memory.category = memoryJson["category"];
                }
                if (memoryJson.contains("latitude")) {
                    memory.latitude = memoryJson["latitude"];
                }
                if (memoryJson.contains("longitude")) {
                    memory.longitude = memoryJson["longitude"];
                }
                if (memoryJson.contains("location")) {
                    memory.location = memoryJson["location"];
                }
                
                memories.push_back(memory);
            } catch (const std::exception& e) {
                std::cerr << "MemoryStorage: Error parsing memory: " << e.what() << std::endl;
                continue;
            }
        }
        
        return memories;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in getPublicMemories: " << e.what() << std::endl;
        return memories;
    }
}

// Search memories by category
std::vector<Memory> MemoryStorage::searchByCategory(const std::string& category, const Wallet& wallet) {
    std::vector<Memory> results;
    if (!m_db) return results;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get all memories visible to the user (public + owned private)
        std::vector<Memory> allMemories = getPublicMemories();
        std::vector<Memory> ownedMemories = getMemoriesByOwner(wallet.getPublicAddress(), wallet);
        
        // Combine the lists (avoiding duplicates)
        std::map<std::string, bool> addedIds;
        for (const auto& memory : allMemories) {
            if (memory.category == category) {
                results.push_back(memory);
                addedIds[memory.id] = true;
            }
        }
        
        for (const auto& memory : ownedMemories) {
            if (addedIds.find(memory.id) == addedIds.end() && memory.category == category) {
                results.push_back(memory);
            }
        }
        
        return results;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in searchByCategory: " << e.what() << std::endl;
        return results;
    }
}

// Search memories by tags
std::vector<Memory> MemoryStorage::searchByTags(const std::vector<std::string>& tags, const Wallet& wallet) {
    std::vector<Memory> results;
    if (!m_db || tags.empty()) return results;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get all memories visible to the user (public + owned private)
        std::vector<Memory> allMemories = getPublicMemories();
        std::vector<Memory> ownedMemories = getMemoriesByOwner(wallet.getPublicAddress(), wallet);
        
        // Combine the lists (avoiding duplicates)
        std::map<std::string, bool> addedIds;
        
        // Helper function to check if memory has any of the tags
        auto hasAnyTag = [&tags](const Memory& memory) {
            for (const auto& tag : memory.tags) {
                for (const auto& searchTag : tags) {
                    if (tag == searchTag) {
                        return true;
                    }
                }
            }
            return false;
        };
        
        for (const auto& memory : allMemories) {
            if (hasAnyTag(memory)) {
                results.push_back(memory);
                addedIds[memory.id] = true;
            }
        }
        
        for (const auto& memory : ownedMemories) {
            if (addedIds.find(memory.id) == addedIds.end() && hasAnyTag(memory)) {
                results.push_back(memory);
            }
        }
        
        return results;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in searchByTags: " << e.what() << std::endl;
        return results;
    }
}

// Search memories by location name
std::vector<Memory> MemoryStorage::searchByLocation(const std::string& location, const Wallet& wallet) {
    std::vector<Memory> results;
    if (!m_db || location.empty()) return results;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get all memories visible to the user (public + owned private)
        std::vector<Memory> allMemories = getPublicMemories();
        std::vector<Memory> ownedMemories = getMemoriesByOwner(wallet.getPublicAddress(), wallet);
        
        // Combine the lists (avoiding duplicates)
        std::map<std::string, bool> addedIds;
        
        // Use case-insensitive search
        std::string lowerLocation = location;
        std::transform(lowerLocation.begin(), lowerLocation.end(), lowerLocation.begin(), ::tolower);
        
        auto locationMatches = [&lowerLocation](const Memory& memory) {
            if (memory.location.empty()) {
                return false;
            }
            
            std::string lowerMemoryLocation = memory.location;
            std::transform(lowerMemoryLocation.begin(), lowerMemoryLocation.end(), lowerMemoryLocation.begin(), ::tolower);
            
            return lowerMemoryLocation.find(lowerLocation) != std::string::npos;
        };
        
        for (const auto& memory : allMemories) {
            if (locationMatches(memory)) {
                results.push_back(memory);
                addedIds[memory.id] = true;
            }
        }
        
        for (const auto& memory : ownedMemories) {
            if (addedIds.find(memory.id) == addedIds.end() && locationMatches(memory)) {
                results.push_back(memory);
            }
        }
        
        return results;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in searchByLocation: " << e.what() << std::endl;
        return results;
    }
}

// Search memories by proximity
std::vector<Memory> MemoryStorage::searchByProximity(double latitude, double longitude, double radiusKm, const Wallet& wallet) {
    std::vector<Memory> results;
    if (!m_db) return results;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get all memories visible to the user (public + owned private)
        std::vector<Memory> allMemories = getPublicMemories();
        std::vector<Memory> ownedMemories = getMemoriesByOwner(wallet.getPublicAddress(), wallet);
        
        // Combine the lists (avoiding duplicates)
        std::map<std::string, bool> addedIds;
        
        // Helper function to calculate Haversine distance (great-circle distance) in kilometers
        auto haversineDistance = [](double lat1, double lon1, double lat2, double lon2) -> double {
            const double R = 6371.0; // Earth radius in kilometers
            const double toRad = 3.14159265358979323846 / 180.0;
            
            double dLat = (lat2 - lat1) * toRad;
            double dLon = (lon2 - lon1) * toRad;
            
            double a = std::sin(dLat/2) * std::sin(dLat/2) +
                       std::cos(lat1 * toRad) * std::cos(lat2 * toRad) *
                       std::sin(dLon/2) * std::sin(dLon/2);
            
            double c = 2 * std::atan2(std::sqrt(a), std::sqrt(1-a));
            return R * c;
        };
        
        auto isWithinRadius = [&](const Memory& memory) {
            if (memory.latitude == 0 && memory.longitude == 0) {
                return false; // No valid coordinates
            }
            
            double distance = haversineDistance(latitude, longitude, memory.latitude, memory.longitude);
            return distance <= radiusKm;
        };
        
        for (const auto& memory : allMemories) {
            if (isWithinRadius(memory)) {
                results.push_back(memory);
                addedIds[memory.id] = true;
            }
        }
        
        for (const auto& memory : ownedMemories) {
            if (addedIds.find(memory.id) == addedIds.end() && isWithinRadius(memory)) {
                results.push_back(memory);
            }
        }
        
        return results;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in searchByProximity: " << e.what() << std::endl;
        return results;
    }
}

// Update memory metadata
bool MemoryStorage::updateMemory(const std::string& id, const Memory& updatedMemory, const Wallet& wallet) {
    if (!m_db) return false;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get the existing memory
        std::string serializedMemory;
        leveldb::Status status = m_db->Get(leveldb::ReadOptions(), memoryKey(id), &serializedMemory);
        
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Memory not found with ID: " << id << std::endl;
            return false;
        }
        
        json memoryJson = json::parse(serializedMemory);
        std::string ownerAddress = memoryJson["ownerAddress"];
        
        // Check if wallet is the owner
        if (!isMemoryOwner(ownerAddress, wallet)) {
            std::cerr << "MemoryStorage: Access denied - only the owner can update the memory" << std::endl;
            return false;
        }
        
        // Update fields (except id, ownerAddress, and hash)
        memoryJson["title"] = updatedMemory.title;
        memoryJson["description"] = updatedMemory.description;
        memoryJson["tags"] = updatedMemory.tags;
        memoryJson["isPrivate"] = updatedMemory.isPrivate;
        
        // Update new fields if provided
        if (!updatedMemory.category.empty()) {
            memoryJson["category"] = updatedMemory.category;
        }
        if (updatedMemory.latitude != 0) {
            memoryJson["latitude"] = updatedMemory.latitude;
        }
        if (updatedMemory.longitude != 0) {
            memoryJson["longitude"] = updatedMemory.longitude;
        }
        if (!updatedMemory.location.empty()) {
            memoryJson["location"] = updatedMemory.location;
        }
        
        // Write back to database
        status = m_db->Put(leveldb::WriteOptions(), memoryKey(id), memoryJson.dump());
        
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Failed to update memory: " << status.ToString() << std::endl;
            return false;
        }
        
        std::cout << "MemoryStorage: Successfully updated memory with ID: " << id << std::endl;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in updateMemory: " << e.what() << std::endl;
        return false;
    }
}

// Delete a memory
bool MemoryStorage::deleteMemory(const std::string& id, const Wallet& wallet) {
    if (!m_db) return false;
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    try {
        // First get the existing memory
        std::string serializedMemory;
        leveldb::Status status = m_db->Get(leveldb::ReadOptions(), memoryKey(id), &serializedMemory);
        
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Memory not found with ID: " << id << std::endl;
            return false;
        }
        
        json memoryJson = json::parse(serializedMemory);
        std::string ownerAddress = memoryJson["ownerAddress"];
        std::string hash = memoryJson["hash"];
        
        // Check if wallet is the owner
        if (!isMemoryOwner(ownerAddress, wallet)) {
            std::cerr << "MemoryStorage: Access denied - only the owner can delete the memory" << std::endl;
            return false;
        }
        
        // Delete from database
        leveldb::WriteBatch batch;
        
        // Delete main memory entry
        batch.Delete(memoryKey(id));
        
        // Delete hash index
        batch.Delete(hashIndexKey(hash));
        
        // Delete owner index
        batch.Delete(ownerIndexKey(ownerAddress, id));
        
        status = m_db->Write(leveldb::WriteOptions(), &batch);
        
        if (!status.ok()) {
            std::cerr << "MemoryStorage: Failed to delete memory: " << status.ToString() << std::endl;
            return false;
        }
        
        std::cout << "MemoryStorage: Successfully deleted memory with ID: " << id << std::endl;
        return true;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Exception in deleteMemory: " << e.what() << std::endl;
        return false;
    }
}

// Helper methods

std::string MemoryStorage::memoryKey(const std::string& id) const {
    return MEMORY_PREFIX + id;
}

std::string MemoryStorage::hashIndexKey(const std::string& hash) const {
    return HASH_INDEX_PREFIX + hash;
}

std::string MemoryStorage::ownerIndexKey(const std::string& ownerAddress, const std::string& id) const {
    return OWNER_INDEX_PREFIX + ownerAddress + ":" + id;
}

std::string MemoryStorage::generateUniqueId() const {
    // Generate a random UUID-like ID
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(0, 15);
    static std::uniform_int_distribution<> dis2(8, 11);
    
    std::stringstream ss;
    ss << std::hex;
    
    for (int i = 0; i < 8; i++) {
        ss << dis(gen);
    }
    ss << "-";
    for (int i = 0; i < 4; i++) {
        ss << dis(gen);
    }
    ss << "-4";  // Version 4 UUID
    for (int i = 0; i < 3; i++) {
        ss << dis(gen);
    }
    ss << "-";
    ss << dis2(gen);
    for (int i = 0; i < 3; i++) {
        ss << dis(gen);
    }
    ss << "-";
    for (int i = 0; i < 12; i++) {
        ss << dis(gen);
    }
    
    return ss.str();
}

std::string MemoryStorage::encryptContent(const std::string& content, const Wallet& wallet) const {
    // Simple encryption using the wallet's public key
    // In a real implementation, this would use more sophisticated encryption
    try {
        // For this example, using a simple XOR with a derived key
        std::string publicKey = wallet.getPublicAddress();
        std::string encryptionKey = Utils::sha256(publicKey).substr(0, 32);
        
        std::string encrypted;
        encrypted.reserve(content.length());
        
        for (size_t i = 0; i < content.length(); i++) {
            encrypted.push_back(content[i] ^ encryptionKey[i % encryptionKey.length()]);
        }
        
        // Base64 encode for storage
        std::string base64 = Utils::base64Encode(encrypted);
        return base64;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Encryption error: " << e.what() << std::endl;
        return "";
    }
}

std::string MemoryStorage::decryptContent(const std::string& encryptedContent, const Wallet& wallet) const {
    // Simple decryption using the wallet's public key
    try {
        // First base64 decode
        std::string encrypted = Utils::base64Decode(encryptedContent);
        
        // Then decrypt using the same XOR method
        std::string publicKey = wallet.getPublicAddress();
        std::string encryptionKey = Utils::sha256(publicKey).substr(0, 32);
        
        std::string decrypted;
        decrypted.reserve(encrypted.length());
        
        for (size_t i = 0; i < encrypted.length(); i++) {
            decrypted.push_back(encrypted[i] ^ encryptionKey[i % encryptionKey.length()]);
        }
        
        return decrypted;
    } catch (const std::exception& e) {
        std::cerr << "MemoryStorage: Decryption error: " << e.what() << std::endl;
        return "";
    }
}

bool MemoryStorage::isMemoryOwner(const std::string& memoryOwnerAddress, const Wallet& wallet) const {
    // Check if the wallet's public address matches the memory owner address
    return wallet.getPublicAddress() == memoryOwnerAddress;
}