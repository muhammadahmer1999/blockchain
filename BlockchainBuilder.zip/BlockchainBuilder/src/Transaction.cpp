#include "../include/Transaction.h"
#include "../include/Utils.h"
#include "../include/Wallet.h"
#include <sstream>

Transaction::Transaction() {
    this->fromAddress = "";
    this->toAddress = "";
    this->amount = 0.0;
    this->signature = "";
    this->data = "";
}

Transaction::Transaction(const std::string& fromAddress, const std::string& toAddress, double amount) {
    this->fromAddress = fromAddress;
    this->toAddress = toAddress;
    this->amount = amount;
    this->signature = "";
    this->data = "";
}

std::string Transaction::calculateHash() const {
    std::stringstream ss;
    ss << fromAddress << toAddress << amount << data;
    return Utils::sha256(ss.str());
}

void Transaction::signTransaction(const std::string& signingKey) {
    // A miner reward transaction doesn't need signing
    if (fromAddress.empty()) {
        return;
    }
    
    // You can only spend your own coins
    Wallet wallet = Wallet::fromPrivateKey(signingKey);
    if (wallet.getPublicKey() != fromAddress) {
        throw std::runtime_error("You cannot sign transactions for other wallets!");
    }
    
    std::string txHash = calculateHash();
    this->signature = wallet.sign(txHash);
}

bool Transaction::isValid() const {
    // Mining rewards don't need validation
    if (fromAddress.empty()) {
        return true;
    }
    
    if (signature.empty()) {
        throw std::runtime_error("No signature in this transaction");
    }
    
    return Wallet::verify(fromAddress, calculateHash(), signature);
}

json Transaction::toJson() const {
    json j;
    j["fromAddress"] = fromAddress;
    j["toAddress"] = toAddress;
    j["amount"] = amount;
    j["signature"] = signature;
    if (!data.empty()) {
        j["data"] = data;
    }
    return j;
}

Transaction Transaction::fromJson(const json& j) {
    std::string fromAddress = j["fromAddress"];
    std::string toAddress = j["toAddress"];
    double amount = j["amount"];
    
    Transaction tx(fromAddress, toAddress, amount);
    tx.signature = j["signature"];
    
    // Load optional data field
    if (j.contains("data")) {
        tx.data = j["data"];
    }
    
    return tx;
}
