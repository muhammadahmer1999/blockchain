#include "../include/Sharding.h"
#include "../src/utils.h"
#include <iostream>
#include <thread>
#include <algorithm>
#include <random>
#include <chrono>
#include <sstream>
#include <iomanip>

// Initialize static variables
const size_t ShardManager::DEFAULT_SHARD_COUNT = 16;
std::mutex ShardManager::s_shardMutex;

// Constructor with default shard count
ShardManager::ShardManager()
    : m_shardCount(DEFAULT_SHARD_COUNT) {
    // Initialize with default config (testnet)
    m_config = {
        .enableDynamicSharding = true,
        .isMainnet = false,
        .enableShardRebalancing = true,
        .rebalanceInterval = 3600, // 1 hour
        .targetBalanceRatio = 0.85, // 85% balance target
        .maxTransactionsPerShard = 1000
    };
    
    initializeShards();
}

// Constructor with specified shard count
ShardManager::ShardManager(size_t shardCount)
    : m_shardCount(shardCount > 0 ? shardCount : DEFAULT_SHARD_COUNT) {
    // Initialize with default config (testnet)
    m_config = {
        .enableDynamicSharding = true,
        .isMainnet = false,
        .enableShardRebalancing = true,
        .rebalanceInterval = 3600, // 1 hour
        .targetBalanceRatio = 0.85, // 85% balance target
        .maxTransactionsPerShard = 1000
    };
    
    initializeShards();
}

// Constructor with specified shard count and mainnet mode
ShardManager::ShardManager(size_t shardCount, bool isMainnet)
    : m_shardCount(shardCount > 0 ? shardCount : DEFAULT_SHARD_COUNT) {
    
    if (isMainnet) {
        // Stricter and more optimized config for mainnet
        m_config = {
            .enableDynamicSharding = true,
            .isMainnet = true,
            .enableShardRebalancing = true,
            .rebalanceInterval = 1800, // 30 minutes
            .targetBalanceRatio = 0.95, // 95% balance target (stricter)
            .maxTransactionsPerShard = 5000 // Higher capacity for mainnet
        };
        
        std::cout << "Initializing shard manager in MAINNET mode with optimized settings" << std::endl;
    } else {
        // Default testnet config
        m_config = {
            .enableDynamicSharding = true,
            .isMainnet = false,
            .enableShardRebalancing = true,
            .rebalanceInterval = 3600, // 1 hour
            .targetBalanceRatio = 0.85, // 85% balance target
            .maxTransactionsPerShard = 1000
        };
        
        std::cout << "Initializing shard manager in TESTNET mode" << std::endl;
    }
    
    initializeShards();
}

// Initialize the shards
void ShardManager::initializeShards() {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    m_shards.clear();
    m_shards.resize(m_shardCount);
    
    std::cout << "Initialized " << m_shardCount << " shards for Ahmiyat Blockchain" << std::endl;
}

// Assign transaction to a shard based on address
size_t ShardManager::getShardForAddress(const std::string& address) const {
    // If address is empty, use a random shard
    if (address.empty()) {
        return getRandomShard();
    }
    
    // Use a hash of the address to determine the shard
    // This ensures the same address always goes to the same shard
    std::string hash = Utils::sha256(address);
    
    // Convert first 8 characters of hash to integer and mod by shard count
    std::stringstream ss;
    ss << std::hex << hash.substr(0, 8);
    size_t value;
    ss >> value;
    
    return value % m_shardCount;
}

// Get a random shard
size_t ShardManager::getRandomShard() const {
    // Use a random generator seeded with current time
    auto seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine generator(seed);
    std::uniform_int_distribution<size_t> distribution(0, m_shardCount - 1);
    
    return distribution(generator);
}

// Add transaction to appropriate shard
bool ShardManager::addTransaction(const Transaction& transaction) {
    // Determine which shard this transaction belongs to
    size_t shardIndex = getShardForAddress(transaction.getFromAddress());
    
    // Add the transaction to the appropriate shard
    std::lock_guard<std::mutex> lock(s_shardMutex);
    if (shardIndex < m_shards.size()) {
        m_shards[shardIndex].push_back(transaction);
        
        std::cout << "Transaction added to shard " << shardIndex << std::endl;
        return true;
    }
    
    std::cerr << "Error: Invalid shard index: " << shardIndex << std::endl;
    return false;
}

// Get all transactions from a specific shard
std::vector<Transaction> ShardManager::getTransactionsFromShard(size_t shardIndex) const {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    if (shardIndex < m_shards.size()) {
        return m_shards[shardIndex];
    }
    
    // Return empty vector for invalid shard index
    return std::vector<Transaction>();
}

// Get all pending transactions from all shards (with optional limit)
std::vector<Transaction> ShardManager::getAllTransactions(size_t limit) const {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    std::vector<Transaction> allTransactions;
    size_t count = 0;
    
    // Collect transactions from all shards
    for (const auto& shard : m_shards) {
        for (const auto& tx : shard) {
            allTransactions.push_back(tx);
            count++;
            
            if (limit > 0 && count >= limit) {
                return allTransactions;
            }
        }
    }
    
    return allTransactions;
}

// Clear transactions from a specific shard
void ShardManager::clearShard(size_t shardIndex) {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    if (shardIndex < m_shards.size()) {
        m_shards[shardIndex].clear();
    }
}

// Clear all transactions from all shards
void ShardManager::clearAllShards() {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    for (auto& shard : m_shards) {
        shard.clear();
    }
}

// Get the current number of shards
size_t ShardManager::getShardCount() const {
    return m_shardCount;
}

// Resize the number of shards (this is a costly operation)
void ShardManager::resizeShards(size_t newShardCount) {
    if (newShardCount == 0) {
        std::cerr << "Error: Cannot resize to 0 shards" << std::endl;
        return;
    }
    
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    // Collect all transactions
    std::vector<Transaction> allTransactions;
    for (const auto& shard : m_shards) {
        allTransactions.insert(allTransactions.end(), shard.begin(), shard.end());
    }
    
    // Update shard count and resize the shards vector
    m_shardCount = newShardCount;
    m_shards.clear();
    m_shards.resize(m_shardCount);
    
    // Redistribute all transactions to the new shards
    for (const auto& tx : allTransactions) {
        size_t shardIndex = getShardForAddress(tx.getFromAddress());
        if (shardIndex < m_shards.size()) {
            m_shards[shardIndex].push_back(tx);
        }
    }
    
    std::cout << "Resized to " << m_shardCount << " shards and redistributed " 
              << allTransactions.size() << " transactions" << std::endl;
}

// Get statistics about the shards
ShardManager::ShardStats ShardManager::getShardStatistics() const {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    ShardStats stats;
    stats.shardCount = m_shardCount;
    stats.totalTransactions = 0;
    stats.transactionsPerShard.resize(m_shardCount);
    stats.lastRebalanceTime = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()
        ).count()
    );
    
    // Calculate statistics
    for (size_t i = 0; i < m_shards.size(); i++) {
        stats.transactionsPerShard[i] = m_shards[i].size();
        stats.totalTransactions += m_shards[i].size();
    }
    
    // Calculate balance ratio (1.0 = perfect balance)
    double avgTxPerShard = stats.totalTransactions / static_cast<double>(m_shardCount);
    if (avgTxPerShard < 1.0) {
        // If hardly any transactions, consider it balanced
        stats.balanceRatio = 1.0;
    } else {
        double maxDeviation = 0.0;
        for (size_t i = 0; i < m_shards.size(); i++) {
            double deviation = std::abs(stats.transactionsPerShard[i] - avgTxPerShard) / avgTxPerShard;
            maxDeviation = std::max(maxDeviation, deviation);
        }
        stats.balanceRatio = 1.0 - maxDeviation;
    }
    
    // Print detailed shard stats if in mainnet mode
    if (m_config.isMainnet) {
        std::cout << "======== MAINNET SHARD STATISTICS ========" << std::endl;
        std::cout << "Total shards: " << stats.shardCount << std::endl;
        std::cout << "Total transactions: " << stats.totalTransactions << std::endl;
        std::cout << "Balance ratio: " << std::fixed << std::setprecision(4) 
                  << stats.balanceRatio << " (target: " 
                  << m_config.targetBalanceRatio << ")" << std::endl;
                  
        // Print individual shard data
        for (size_t i = 0; i < m_shards.size(); i++) {
            std::cout << "Shard " << std::setw(2) << i << ": " 
                      << std::setw(6) << stats.transactionsPerShard[i] << " transactions" << std::endl;
        }
        
        // Indicate if rebalancing is needed
        if (stats.balanceRatio < m_config.targetBalanceRatio) {
            std::cout << "WARNING: Shard balance below target threshold, rebalancing recommended" << std::endl;
        }
        
        std::cout << "==========================================" << std::endl;
    }
    
    return stats;
}

// Process all shards in parallel (each shard gets its own thread)
void ShardManager::processAllShardsInParallel(std::function<void(const std::vector<Transaction>&)> processor) {
    std::lock_guard<std::mutex> lock(s_shardMutex);
    
    std::vector<std::thread> threads;
    
    // Create a thread for each shard
    for (const auto& shard : m_shards) {
        threads.emplace_back([&processor, &shard]() {
            processor(shard);
        });
    }
    
    // Wait for all threads to complete
    for (auto& t : threads) {
        if (t.joinable()) {
            t.join();
        }
    }
}