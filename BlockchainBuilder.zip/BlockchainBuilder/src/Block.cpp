#include "../include/Block.h"
#include "../include/Utils.h"
#include <iostream>
#include <sstream>
#include <string>

Block::Block(unsigned int index, const std::string& previousHash, const std::vector<Transaction>& transactions) {
    this->index = index;
    this->previousHash = previousHash;
    this->transactions = transactions;
    this->timestamp = time(nullptr);
    this->nonce = 0;
    this->hash = calculateHash();
}

std::string Block::calculateHash() const {
    std::stringstream ss;
    ss << index << timestamp << previousHash;
    
    // Add all transaction hashes
    for (const auto& tx : transactions) {
        ss << tx.calculateHash();
    }
    
    ss << nonce;
    
    return Utils::sha256(ss.str());
}

void Block::mineBlock(unsigned int difficulty) {
    std::string target(difficulty, '0');
    
    while (hash.substr(0, difficulty) != target) {
        nonce++;
        hash = calculateHash();
    }
    
    std::cout << "Block mined: " << hash << std::endl;
}

bool Block::hasValidTransactions() const {
    for (const auto& tx : transactions) {
        if (!tx.isValid()) {
            return false;
        }
    }
    return true;
}

json Block::toJson() const {
    json j;
    j["index"] = index;
    j["timestamp"] = timestamp;
    j["previousHash"] = previousHash;
    j["hash"] = hash;
    j["nonce"] = nonce;
    
    json txJson = json::array();
    for (const auto& tx : transactions) {
        txJson.push_back(tx.toJson());
    }
    j["transactions"] = txJson;
    
    return j;
}

Block Block::fromJson(const json& j) {
    unsigned int index = j["index"];
    std::string previousHash = j["previousHash"];
    
    std::vector<Transaction> transactions;
    for (const auto& txJson : j["transactions"]) {
        transactions.push_back(Transaction::fromJson(txJson));
    }
    
    Block block(index, previousHash, transactions);
    block.timestamp = j["timestamp"];
    block.hash = j["hash"];
    block.nonce = j["nonce"];
    
    return block;
}
