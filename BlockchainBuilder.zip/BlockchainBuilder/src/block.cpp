/**
 * @file block.cpp
 * @brief Implementation of the Block class
 */

#include "block.h"
#include "utils.h"
#include <nlohmann/json.hpp>
#include <sstream>
#include <iostream>
#include <iomanip>

using json = nlohmann::json;

Block::Block()
    : m_index(0),
      m_timestamp(std::chrono::system_clock::now()),
      m_transactions(),
      m_previousHash("0"),
      m_nonce(0),
      m_hash("") {
}

Block::Block(uint32_t index, 
             std::chrono::system_clock::time_point timestamp, 
             const std::vector<Transaction>& transactions, 
             const std::string& previousHash)
    : m_index(index),
      m_timestamp(timestamp),
      m_transactions(transactions),
      m_previousHash(previousHash),
      m_nonce(0) {
    m_hash = calculateHash();
}

std::string Block::calculateHash() const {
    std::stringstream ss;
    ss << m_index << Utils::timePointToString(m_timestamp) << m_previousHash << m_nonce;
    
    // Add all transaction data
    for (const auto& tx : m_transactions) {
        ss << tx.toString();
    }
    
    return Utils::sha256(ss.str());
}

void Block::mineBlock(uint32_t difficulty) {
    std::string target(difficulty, '0');
    
    while (m_hash.substr(0, difficulty) != target) {
        m_nonce++;
        m_hash = calculateHash();
        
        // Print a progress indicator every 100000 iterations
        if (m_nonce % 100000 == 0) {
            std::cout << "Mining... Nonce: " << m_nonce << ", Hash: " << m_hash << std::endl;
        }
    }
    
    std::cout << "Block mined: " << m_hash << std::endl;
}

uint32_t Block::getIndex() const {
    return m_index;
}

std::chrono::system_clock::time_point Block::getTimestamp() const {
    return m_timestamp;
}

uint64_t Block::getNonce() const {
    return m_nonce;
}

const std::string& Block::getHash() const {
    return m_hash;
}

const std::string& Block::getPreviousHash() const {
    return m_previousHash;
}

const std::vector<Transaction>& Block::getTransactions() const {
    return m_transactions;
}

void Block::setIndex(uint32_t index) {
    m_index = index;
}

void Block::setHash(const std::string& hash) {
    m_hash = hash;
}

void Block::setPreviousHash(const std::string& prevHash) {
    m_previousHash = prevHash;
}

void Block::setNonce(uint64_t nonce) {
    m_nonce = nonce;
}

void Block::setTransactions(const std::vector<Transaction>& transactions) {
    m_transactions = transactions;
}

std::string Block::toJson() const {
    json j;
    j["index"] = m_index;
    j["timestamp"] = Utils::timePointToString(m_timestamp);
    j["nonce"] = m_nonce;
    j["hash"] = m_hash;
    j["previousHash"] = m_previousHash;
    
    json txs = json::array();
    for (const auto& tx : m_transactions) {
        json txJson;
        txJson["fromAddress"] = tx.getFromAddress();
        txJson["toAddress"] = tx.getToAddress();
        txJson["amount"] = tx.getAmount();
        txJson["timestamp"] = Utils::timePointToString(tx.getTimestamp());
        txJson["signature"] = tx.getSignature();
        txs.push_back(txJson);
    }
    j["transactions"] = txs;
    
    return j.dump(4);
}
