# Ahmiyat Blockchain

A decentralized blockchain implementation in C++ with Ahmiyat Coin cryptocurrency, designed for testnet and mainnet deployment.

## Features

### Core Blockchain Features
- Decentralized blockchain network architecture
- Advanced block creation and transaction handling
- Proof-of-work consensus algorithm with mining rewards
- Complete chain validation and security measures
- Comprehensive transaction processing with signature verification
- Secure wallet system with key generation and management
- Interactive command-line interface for node operation

### Advanced Features
- Data persistence using LevelDB for blockchain state storage
- RESTful API for external interaction with the blockchain
- Secure node communication with TLS/SSL encryption
- Sharding architecture for improved scalability (16 shards)
- Node synchronization protocols for network consistency
- Memory fragment storage for transaction staging
- Robust error handling and logging system

## Cryptocurrency: Ahmiyat Coin
- Native cryptocurrency with mining capability
- Secure transaction validation and processing
- Wallet balance management system

## Technical Requirements

- C++17 compatible compiler
- Crypto++ library for cryptographic operations
- LevelDB for data persistence
- OpenSSL for secure communications
- libcurl for network requests
- nlohmann/json for data serialization
- CMake (3.10 or higher) for build management
- Pthreads for multi-threading support

## Building the Project

1. Make sure you have all dependencies installed:

   ```bash
   # On Ubuntu/Debian
   sudo apt-get install libcrypto++-dev
   # Install nlohmann/json using your package manager or manually
   ```

2. Clone the repository and build:

   ```bash
   git clone https://github.com/yourusername/simple-blockchain.git
   cd simple-blockchain
   mkdir build && cd build
   cmake ..
   make
   