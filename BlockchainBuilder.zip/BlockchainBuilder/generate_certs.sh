#!/bin/bash

# Script to generate self-signed SSL certificates for the Ahmiyat Blockchain

# Create certificates directory
mkdir -p data/certs
cd data/certs

# Generate private key
openssl genrsa -out key.pem 2048

# Generate certificate signing request (CSR)
openssl req -new -key key.pem -out cert.csr -subj "/C=US/ST=State/L=City/O=Ahmiyat Blockchain/OU=Development/CN=localhost"

# Generate self-signed certificate
openssl x509 -req -days 365 -in cert.csr -signkey key.pem -out cert.pem

# Clean up CSR file
rm cert.csr

echo "SSL certificates generated successfully in data/certs/"
ls -la